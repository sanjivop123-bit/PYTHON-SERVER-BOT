# Feature audit: old vs new vs merged

Inputs: `project_files.zip` (OLD, 9 files, verification server) and `HONESTY_AI_VIP_READY.zip` (NEW, 38 files).
Reviewed: every Python, HTML, CSS, config, Docker, migration and test file. **Neither ZIP contains the Telegram bot
(Telebot) code, a customer-facing UI, VIP membership management, referral tracking, or user-support flows**; those are
therefore not in the merged project and nothing was invented for them.

| Feature | OLD | NEW | MERGED |
|---|---|---|---|
| Trader ID verification + min-deposit evaluation | yes | no (explicitly excluded) | **kept** (`verification_service.py`) |
| Official affiliate API provider | placeholder | n/a | placeholder kept, **not operational** |
| Trader ID <-> one Telegram user binding | yes | no | kept |
| Deposit store with provider IDs, no double counting | yes | no | kept |
| Verification history / status endpoint | yes | no | kept (`/api/v1/status/{id}`) |
| Bot API `POST /api/v1/verify` | `X-API-Key` (>=24) | `X-API-Key` (>=32) | kept; same path/body/response |
| Affiliate event tracking, duplicate prevention | no | yes | kept |
| Postback webhook with header/HMAC auth | shared secret (header or `?token=`) | header/HMAC, disabled by default | new design; `?token=` dropped |
| Re-verify trigger webhook | `/webhooks/affiliate` | n/a | moved to `/webhooks/affiliate/verify` |
| Telegram admin notifications (de-duplicated) | yes (`send_once`) | yes (per event/chat) | both, one `notification_logs` table |
| Telegram user notification of result | yes | no | kept |
| Admin dashboard | HTTP Basic, inline HTML | session + CSRF + Argon2 + filters/pagination | new login; old tables/JSON endpoints added |
| Admin search/filters | Trader ID / username | event ID/type/status/date | both |
| Health / readiness | `/health` (+operational flag) | `/health`, `/api/v1/health` | all; flag kept |
| DB | async SQLAlchemy, `create_all` | async SQLAlchemy + Alembic | Alembic (0001, 0002) |
| Rate limiting, body limits, security headers, HTTPS-only, JSON redacting logs | partial | yes | new |
| Graceful shutdown, non-root Docker | partial | yes | new |
| Tests | none | 6 files | + `test_verification.py` |

## Conflicts resolved
1. **Route** `/webhooks/affiliate` (both) -> new receiver keeps it; old trigger moved (see CHANGELOG).
2. **Model** `notification_log` vs `notification_logs` -> new table with status; old rows migrated.
3. **Policy**: NEW forbids Trader ID/deposit data in the postback pipeline; OLD requires them for verification. Resolved by
   keeping the two paths separate: the postback pipeline still discards those fields; verification stores them only when the
   bot submits a Trader ID and only from the official API's response.
4. **Config** `Settings`: pydantic-settings (old) vs frozen dataclass (new) -> dataclass; old variables mapped (see DEPLOYMENT_GUIDE).
5. **Auth**: Basic admin vs session -> session (stronger); API key lengths unified at >=32.

## Requested but not present in either input (not built)
Telegram bot handlers/menus, free-VIP info, VIP membership management, user support flow, referral tracking,
analytics beyond counts, configuration management UI, error-log viewer, background job queue/retry worker.
(Existing behaviour: failed notifications are recorded and not auto-retried; send_once releases its key on failure so the
next check retries.)
