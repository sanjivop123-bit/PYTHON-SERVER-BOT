# HONESTY AI VIP - Master Server (event tracking + Trader ID/deposit verification)

FastAPI + PostgreSQL service that (1) records neutral affiliate tracking events with duplicate protection,
(2) verifies Trader ID registration/linking and real deposit totals against a minimum, once the official
affiliate API is integrated, (3) sends Telegram admin/user notifications and (4) serves a secured admin dashboard.
This is the merge of the old verification server and the HONESTY_AI_VIP_READY backend (see FEATURE_AUDIT.md).

> **Status - NOT verified as production-ready.** The test suite was written but **never executed** in the build
> environment (no network, so dependencies could not be installed; no Docker). The affiliate provider is a
> **non-operational placeholder**: until you implement `OfficialAffiliateProvider` against the broker's official
> documentation and test it with a real account, `/api/v1/verify` answers `503 not_operational` and no deposit
> data is ever produced. See TEST_REPORT.md.

The existing **Telebot bot is not part of either ZIP and is not modified**; it talks to this server over HTTP
(`POST /api/v1/verify`, header `X-API-Key`).

## Scope and exclusions
Two separate data paths:
- **Event tracking** (`/webhooks/affiliate`, `/api/v1/events`): stores only event ID, event name, click ID, site ID,
  link ID, timestamp, status. Provider fields such as `trader_id`, `sumdep`, `country`, `useragent` are discarded on
  receipt and `WEBHOOK_FIELD_MAP` refuses to map them.
- **Verification** (`/api/v1/verify`, `/webhooks/affiliate/verify`): stores a Trader ID only when the Telegram bot
  submits it on behalf of a user, bound to that Telegram ID, plus deposits exactly as reported by the official API.
  Nothing is fabricated, currencies are never converted, and no profit/performance claims are made anywhere.

## Layout
```
app/            main.py config.py database.py models.py schemas.py security.py
                event_service.py webhook_service.py telegram_service.py admin.py
                api.py logging_config.py verification_service.py templates/ static/
migrations/     Alembic (async) + versions/0001_initial.py, 0002_verification.py
tests/          conftest.py test_health/events/webhooks/security/telegram/verification.py
docker-compose.yml  (local dev)   Dockerfile
scripts/        hash_password.py
```
(`api.py` and `logging_config.py` were added to the requested layout to keep routes and logging separate.)

## Run tests
```
python3.12 -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt
pytest
pip-audit -r requirements.txt
```
Tests use in-memory SQLite and a mocked Telegram transport; nothing external is contacted.

## Run locally
```
export ENVIRONMENT=development DATABASE_URL=postgresql+asyncpg://user:pass@localhost/honesty
export API_KEYS=$(python -c "import secrets;print(secrets.token_urlsafe(40))")
alembic upgrade head
uvicorn app.main:create_app --factory --port 8080
```

## API
| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/health` | none | liveness, no DB; includes `verification_operational` |
| GET | `/api/v1/health` | none | readiness; `503` if DB down |
| POST | `/api/v1/events` | `X-API-Key` | JSON; `201` new, `200` duplicate |
| GET | `/api/v1/events` | `X-API-Key` | filters: `q` (id prefix), `event_name`, `status`, `date_from`, `date_to`, `limit`, `offset` |
| GET | `/api/v1/events/{event_id}` | `X-API-Key` | `404` if unknown |
| GET/POST | `/webhooks/affiliate` | webhook secret/HMAC | event tracking; JSON, form or query string |
| POST | `/api/v1/verify` | `X-API-Key` | body `{telegram_user_id, trader_id, telegram_username?, notify_user?}`; `503` not_operational, `502` provider error, `422` bad Trader ID |
| GET | `/api/v1/status/{trader_id}` | `X-API-Key` | last stored result, `404` if none |
| POST | `/webhooks/affiliate/verify` | webhook secret/HMAC | trigger only: re-verifies a KNOWN Trader ID via the official API (moved from the old `/webhooks/affiliate`) |
| GET | `/admin/api/users`, `/admin/api/history` | session login | JSON, `?q=` filter (`401` without session) |
| GET | `/admin` | session login | also `/admin/login`, `/admin/logout` |

Health endpoints are intentionally unauthenticated (required by Cloud Run probes) and expose no event data.

## Webhook / Quotex postback compatibility
Default mapping (override with `WEBHOOK_FIELD_MAP`): `event_id`←`event_id`, `event_name`←`status`,
`click_id`←`click_id`, `site_id`←`site_id`, `link_id`←`lid`.

Provider configuration requirements and limitations:
1. Provider field names/semantics are **not guaranteed** by this project; confirm them in your dashboard documentation. Unresolved macros such as the literal text `{event_id}` are rejected (422).
2. Use only the macros above. Do **not** add `{trader_id}`, `{sumdep}`, `{sumwithdraw}`, `{country}` or `{useragent}` to the postback URL; if sent they are ignored and never stored or logged.
3. Authentication: the server supports a shared secret in a request header (`WEBHOOK_AUTH_MODE=header`) or an HMAC-SHA256 signature header (`hmac`). Secrets are never accepted in the URL. **If the provider can only send a plain URL with no custom headers or signature, it cannot be authenticated safely: keep `WEBHOOK_AUTH_MODE=disabled`** (the endpoint then answers `503` and stores nothing) until a supported mechanism or an authenticating relay exists. Whether your provider supports headers/signatures is **NOT CONFIGURED / UNVERIFIED**.
4. Event IDs are unique. A repeated `event_id` (even with a different status) is treated as a duplicate and ignored.
5. No broker API endpoint is called or assumed.

## Telegram
Uses `sendMessage` only (no `getUpdates`, no webhook changes), so the existing bot keeps working.
Set `TELEGRAM_BOT_TOKEN` and `ADMIN_CHAT_IDS`; otherwise notifications are reported as `not_configured`.
Each (event, chat) pair is notified once (unique `dedupe_key`). Failed sends are logged in
`notification_logs` and are not retried automatically. Verification notifications (admin + user) use `send_once` de-duplication keys.

## Implementing the affiliate provider (required before verification works)
Edit `OfficialAffiliateProvider.lookup_trader` in `app/verification_service.py` using ONLY the broker's official
documentation, set `IMPLEMENTED = True`, `AFFILIATE_API_BASE_URL`, `AFFILIATE_API_KEY` and `MIN_DEPOSIT`, then test with a
real account. Each deposit needs a stable unique ID. Confirm gross/net amounts, demo-account handling and refunds.
If the platform only offers postbacks (no lookup API), the provider design must be adapted; do not guess endpoints.
