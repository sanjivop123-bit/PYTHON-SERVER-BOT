"""Application factory. Run with: uvicorn app.main:create_app --factory"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from app import admin, api
from app.config import Settings
from app.database import Database
from app.logging_config import configure_logging, log_event
from app.schemas import sanitize_errors
from app.security import BodySizeLimitMiddleware, HTTPSOnlyMiddleware, RateLimiter, SecurityHeadersMiddleware
from app.telegram_service import TelegramService
from app.verification_service import AffiliateProvider, build_provider

logger = logging.getLogger(__name__)
BASE_DIR = Path(__file__).parent


def create_app(
    settings: Optional[Settings] = None,
    telegram: Optional[TelegramService] = None,
    db: Optional[Database] = None,
    provider: Optional[AffiliateProvider] = None,
) -> FastAPI:
    settings = settings or Settings.from_env()
    settings.validate()
    configure_logging(settings.log_level)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        log_event(logger, logging.INFO, "startup", environment=settings.environment)
        if not (app.state.provider.operational and settings.verification_configured):
            log_event(logger, logging.WARNING, "verification_not_operational",
                      detail="affiliate API not implemented/configured or MIN_DEPOSIT unset")
        yield
        # Graceful shutdown (Cloud Run sends SIGTERM): release HTTP client and DB pool.
        await app.state.telegram.aclose()
        await app.state.db.dispose()
        log_event(logger, logging.INFO, "shutdown_complete")

    docs = None if settings.is_production else "/docs"
    app = FastAPI(
        title="HONESTY AI VIP Server",
        version="1.0.0",
        lifespan=lifespan,
        docs_url=docs,
        redoc_url=None,
        openapi_url=None if settings.is_production else "/openapi.json",
    )
    app.state.settings = settings
    app.state.db = db or Database(settings)
    app.state.telegram = telegram or TelegramService(
        settings.telegram_bot_token, settings.admin_chat_ids, settings.telegram_timeout
    )
    app.state.telegram.session_factory = app.state.db.session_factory
    app.state.provider = provider or build_provider(settings)
    app.state.limiter = RateLimiter()

    # add_middleware: last added = outermost
    app.add_middleware(
        SessionMiddleware,
        secret_key=settings.secret_key,
        session_cookie="hv_session",
        max_age=settings.session_max_age,
        same_site="strict",
        https_only=settings.is_production,
    )
    app.add_middleware(BodySizeLimitMiddleware, max_bytes=settings.max_request_bytes)
    app.add_middleware(SecurityHeadersMiddleware, hsts=settings.is_production)
    app.add_middleware(HTTPSOnlyMiddleware, enabled=settings.is_production)

    @app.exception_handler(RequestValidationError)
    async def validation_handler(request: Request, exc: RequestValidationError):
        return JSONResponse({"detail": sanitize_errors(exc.errors())}, status_code=422)

    @app.exception_handler(Exception)
    async def unhandled_handler(request: Request, exc: Exception):
        log_event(logger, logging.ERROR, "unhandled_error", path=request.url.path, error=type(exc).__name__)
        return JSONResponse({"detail": "Internal server error"}, status_code=500)

    app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
    app.include_router(api.router)
    app.include_router(admin.router)
    return app
