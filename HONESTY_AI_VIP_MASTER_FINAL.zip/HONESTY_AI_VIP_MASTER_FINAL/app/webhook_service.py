"""Webhook authentication, payload parsing and field mapping.

Only documented, non-sensitive tracking fields are mapped. Every other field the
provider sends (e.g. trader_id, sumdep, country, useragent) is discarded without
being stored or logged.
"""
from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any, Mapping
from urllib.parse import parse_qs

from app.config import Settings
from app.schemas import EventIn

MAX_FIELDS = 50


class PayloadError(Exception):
    def __init__(self, status: int, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.message = message


def verify_authentication(settings: Settings, headers: Mapping[str, str], method: str, query: bytes, body: bytes) -> bool:
    """Verify the request using the configured, provider-supported mechanism.

    header: static shared secret in a request header (never in the URL).
    hmac:   hex HMAC-SHA256 of the raw body (POST) or raw query string (GET).
    """
    secret = settings.webhook_secret.encode()
    if settings.webhook_auth_mode == "header":
        provided = headers.get(settings.webhook_secret_header)
        return bool(provided) and hmac.compare_digest(provided.encode(), secret)
    if settings.webhook_auth_mode == "hmac":
        provided = headers.get(settings.webhook_signature_header, "")
        provided = provided.removeprefix("sha256=").strip().lower()
        signed = body if method == "POST" else query
        expected = hmac.new(secret, signed, hashlib.sha256).hexdigest()
        return bool(provided) and hmac.compare_digest(provided.encode(), expected.encode())
    return False


def parse_urlencoded(data: bytes) -> dict[str, str]:
    try:
        text = data.decode("utf-8")
        parsed = parse_qs(text, keep_blank_values=True, max_num_fields=MAX_FIELDS)
    except (UnicodeDecodeError, ValueError):
        raise PayloadError(400, "Malformed request data") from None
    return {k: v[0] for k, v in parsed.items()}


def parse_payload(method: str, content_type: str, query: bytes, body: bytes) -> dict[str, str]:
    if method == "GET":
        return parse_urlencoded(query)
    ctype = content_type.split(";")[0].strip().lower()
    if ctype == "application/x-www-form-urlencoded":
        return parse_urlencoded(body)
    if ctype == "application/json":
        try:
            obj: Any = json.loads(body)
        except (ValueError, RecursionError):
            raise PayloadError(400, "Malformed JSON") from None
        if not isinstance(obj, dict) or len(obj) > MAX_FIELDS:
            raise PayloadError(400, "JSON body must be an object")
        out: dict[str, str] = {}
        for key, value in obj.items():
            if value is None:
                continue
            if isinstance(value, (dict, list, bool)):
                raise PayloadError(400, "Nested or boolean values are not supported")
            out[str(key)] = str(value)
        return out
    raise PayloadError(415, "Unsupported content type")


def build_event(raw: Mapping[str, str], field_map: Mapping[str, str]) -> EventIn:
    """Map provider parameters to internal fields. Raises pydantic.ValidationError."""
    mapped = {}
    for internal, source in field_map.items():
        value = raw.get(source)
        if value is None or value.strip() == "":
            continue
        mapped[internal] = value
    return EventIn.model_validate(mapped)


def ignored_field_count(raw: Mapping[str, str], field_map: Mapping[str, str]) -> int:
    return len(set(raw) - set(field_map.values()))
