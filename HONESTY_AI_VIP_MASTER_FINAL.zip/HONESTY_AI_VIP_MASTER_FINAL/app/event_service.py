"""Event persistence, duplicate prevention, processing and queries."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from typing import Optional

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from app.logging_config import log_event
from app.models import Event, NotificationLog, as_utc, utcnow
from app.schemas import EventIn
from app.telegram_service import TelegramService

logger = logging.getLogger(__name__)


@dataclass
class ProcessResult:
    event: dict
    created: bool
    notification: str


def _iso(value: Optional[datetime]) -> Optional[str]:
    value = as_utc(value)
    return value.isoformat() if value else None


def event_to_dict(e: Event) -> dict:
    return {
        "id": e.id,
        "event_id": e.external_event_id,
        "event_name": e.event_name,
        "click_id": e.click_id,
        "site_id": e.site_id,
        "link_id": e.link_id,
        "event_timestamp": _iso(e.event_timestamp),
        "received_at": _iso(e.received_at),
        "processed_at": _iso(e.processed_at),
        "processing_status": e.processing_status,
        "source": e.source,
        "failure_reason": e.failure_reason,
    }


async def get_event(session: AsyncSession, external_event_id: str) -> Optional[Event]:
    res = await session.execute(select(Event).where(Event.external_event_id == external_event_id))
    return res.scalar_one_or_none()


async def create_event(session: AsyncSession, data: EventIn, source: str) -> tuple[Event, bool]:
    """Insert an event. Returns (event, created); created=False means duplicate."""
    existing = await get_event(session, data.event_id)
    if existing is not None:
        return existing, False
    event = Event(
        external_event_id=data.event_id,
        event_name=data.event_name,
        click_id=data.click_id,
        site_id=data.site_id,
        link_id=data.link_id,
        event_timestamp=data.event_timestamp,
        source=source,
        received_at=utcnow(),
        processing_status="received",
    )
    session.add(event)
    try:
        await session.commit()
    except IntegrityError:  # concurrent insert of the same event id (unique constraint)
        await session.rollback()
        existing = await get_event(session, data.event_id)
        if existing is None:
            raise
        return existing, False
    return event, True


async def _mark_failed(session: AsyncSession, external_event_id: str, reason: str) -> None:
    try:
        event = await get_event(session, external_event_id)
        if event is not None:
            event.processing_status = "failed"
            event.failure_reason = reason
            await session.commit()
    except SQLAlchemyError:
        await session.rollback()


async def process_event(
    session: AsyncSession, telegram: TelegramService, data: EventIn, source: str
) -> ProcessResult:
    event, created = await create_event(session, data, source)
    if not created:
        log_event(logger, logging.INFO, "event_duplicate", event_id=data.event_id)
        return ProcessResult(event_to_dict(event), False, "skipped_duplicate")
    try:
        event.processing_status = "processed"
        event.processed_at = utcnow()
        event.failure_reason = None
        await session.commit()
    except SQLAlchemyError:
        await session.rollback()
        await _mark_failed(session, data.event_id, "processing_error")
        log_event(logger, logging.ERROR, "event_processing_failed", event_id=data.event_id)
        raise
    snapshot = event_to_dict(event)
    try:
        notification = await telegram.notify_event(
            session, data.event_id, data.event_name, as_utc(event.processed_at)
        )
    except Exception as exc:  # noqa: BLE001 - notification problems must not fail the event
        await session.rollback()
        notification = "error"
        log_event(logger, logging.ERROR, "notification_error", event_id=data.event_id, error=type(exc).__name__)
    log_event(
        logger, logging.INFO, "event_processed",
        event_id=data.event_id, event_name=data.event_name, source=source, notification=notification,
    )
    return ProcessResult(snapshot, True, notification)


def _filters(q, event_name, status, date_from: Optional[date], date_to: Optional[date]):
    conds = []
    if q:
        conds.append(Event.external_event_id.startswith(q, autoescape=True))
    if event_name:
        conds.append(Event.event_name == event_name.lower())
    if status:
        conds.append(Event.processing_status == status)
    if date_from:
        conds.append(Event.received_at >= datetime.combine(date_from, time.min, tzinfo=timezone.utc))
    if date_to:
        conds.append(Event.received_at < datetime.combine(date_to + timedelta(days=1), time.min, tzinfo=timezone.utc))
    return conds


async def list_events(
    session: AsyncSession,
    *,
    q: Optional[str] = None,
    event_name: Optional[str] = None,
    status: Optional[str] = None,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    limit: int = 25,
    offset: int = 0,
) -> tuple[list[Event], int]:
    conds = _filters(q, event_name, status, date_from, date_to)
    total = (await session.execute(select(func.count()).select_from(Event).where(*conds))).scalar_one()
    rows = await session.execute(
        select(Event).where(*conds).order_by(Event.received_at.desc(), Event.id.desc()).limit(limit).offset(offset)
    )
    return list(rows.scalars().all()), total


async def get_stats(session: AsyncSession) -> dict:
    rows = (await session.execute(select(Event.processing_status, func.count()).group_by(Event.processing_status))).all()
    counts = {s: c for s, c in rows}
    notif = (
        await session.execute(
            select(NotificationLog.notification_status, func.count()).group_by(NotificationLog.notification_status)
        )
    ).all()
    return {
        "total": sum(counts.values()),
        "processed": counts.get("processed", 0),
        "failed": counts.get("failed", 0),
        "received": counts.get("received", 0),
        "notifications": {s: c for s, c in notif},
    }


async def distinct_event_names(session: AsyncSession, limit: int = 50) -> list[str]:
    rows = await session.execute(select(Event.event_name).distinct().order_by(Event.event_name).limit(limit))
    return [r[0] for r in rows.all()]
