"""Environment-driven configuration. Secrets only ever come from environment variables."""
from __future__ import annotations

import json
import os
import re
import secrets
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Mapping, Optional

# Internal field -> default provider (Quotex-style postback) parameter name.
# Only these non-sensitive tracking fields are supported.
DEFAULT_FIELD_MAP: dict[str, str] = {
    "event_id": "event_id",
    "event_name": "status",
    "click_id": "click_id",
    "site_id": "site_id",
    "link_id": "lid",
}
ALLOWED_INTERNAL_FIELDS = frozenset(DEFAULT_FIELD_MAP) | {"event_timestamp"}
# Provider fields that must never be mapped, stored or processed.
FORBIDDEN_SOURCE_FIELDS = frozenset(
    {"trader_id", "sumdep", "sumwithdraw", "country", "useragent", "deposit", "withdraw", "password", "token"}
)
WEBHOOK_AUTH_MODES = frozenset({"disabled", "header", "hmac"})
ENVIRONMENTS = frozenset({"development", "test", "production"})


class ConfigError(RuntimeError):
    """Raised for invalid configuration. Messages never contain secret values."""


@dataclass(frozen=True)
class Settings:
    environment: str = "development"
    database_url: str = "sqlite+aiosqlite:///./dev.db"
    db_pool_size: int = 5
    db_max_overflow: int = 5
    db_pool_timeout: int = 30
    secret_key: str = ""
    session_max_age: int = 3600
    api_keys: tuple[str, ...] = ()
    admin_username: str = ""
    admin_password_hash: str = ""
    webhook_auth_mode: str = "disabled"
    webhook_secret: str = ""
    webhook_secret_header: str = "X-Webhook-Secret"
    webhook_signature_header: str = "X-Webhook-Signature"
    webhook_methods: tuple[str, ...] = ("GET", "POST")
    webhook_field_map: Mapping[str, str] = field(default_factory=lambda: dict(DEFAULT_FIELD_MAP))
    max_request_bytes: int = 16384
    rate_limit_per_minute: int = 60
    login_rate_limit_per_minute: int = 5
    telegram_bot_token: str = ""
    admin_chat_ids: tuple[str, ...] = ()
    telegram_timeout: float = 10.0
    log_level: str = "INFO"
    # --- Trader ID / deposit verification (ported from the old verification server) ---
    # No default minimum: it must be chosen explicitly. Unset => verification reports not_operational.
    min_deposit: Optional[Decimal] = None
    deposit_currency: str = "USD"
    trader_id_pattern: str = r"^[A-Za-z0-9_-]{3,32}$"
    affiliate_api_base_url: str = ""
    affiliate_api_key: str = ""

    @property
    def verification_configured(self) -> bool:
        return self.min_deposit is not None and self.min_deposit > 0

    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @property
    def admin_configured(self) -> bool:
        return bool(self.admin_username and self.admin_password_hash)

    @property
    def telegram_configured(self) -> bool:
        return bool(self.telegram_bot_token and self.admin_chat_ids)

    def validate(self) -> None:
        errors: list[str] = []
        if self.environment not in ENVIRONMENTS:
            errors.append("ENVIRONMENT must be development, test or production")
        if len(self.secret_key) < 32:
            errors.append("SECRET_KEY must be at least 32 characters")
        if any(len(k) < 32 for k in self.api_keys):
            errors.append("every API key must be at least 32 characters")
        if self.webhook_auth_mode not in WEBHOOK_AUTH_MODES:
            errors.append("WEBHOOK_AUTH_MODE must be disabled, header or hmac")
        if self.webhook_auth_mode in {"header", "hmac"} and len(self.webhook_secret) < 32:
            errors.append("WEBHOOK_SECRET must be at least 32 characters when webhook auth is enabled")
        if self.telegram_bot_token and not self.admin_chat_ids:
            errors.append("ADMIN_CHAT_IDS is required when TELEGRAM_BOT_TOKEN is set")
        if self.min_deposit is not None and self.min_deposit <= 0:
            errors.append("MIN_DEPOSIT must be greater than 0")
        try:
            re.compile(self.trader_id_pattern)
        except re.error:
            errors.append("TRADER_ID_PATTERN is not a valid regular expression")
        if not set(self.webhook_methods) <= {"GET", "POST"}:
            errors.append("WEBHOOK_METHODS may only contain GET and POST")
        for internal, source in self.webhook_field_map.items():
            if internal not in ALLOWED_INTERNAL_FIELDS:
                errors.append(f"WEBHOOK_FIELD_MAP: unsupported internal field '{internal}'")
            if source.lower() in FORBIDDEN_SOURCE_FIELDS:
                errors.append(f"WEBHOOK_FIELD_MAP: provider field '{source}' is forbidden")
        if "event_id" not in self.webhook_field_map or "event_name" not in self.webhook_field_map:
            errors.append("WEBHOOK_FIELD_MAP must map event_id and event_name")
        if self.is_production:
            if self.database_url.startswith("sqlite") or not self.database_url:
                errors.append("DATABASE_URL must point to PostgreSQL in production")
            if not self.api_keys:
                errors.append("API_KEYS is required in production")
            if not self.admin_configured:
                errors.append("ADMIN_USERNAME and ADMIN_PASSWORD_HASH are required in production")
        if errors:
            raise ConfigError("; ".join(errors))

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "Settings":
        env = os.environ if env is None else env
        environment = env.get("ENVIRONMENT", "development").strip().lower()
        field_map = dict(DEFAULT_FIELD_MAP)
        raw_map = env.get("WEBHOOK_FIELD_MAP", "").strip()
        if raw_map:
            try:
                parsed = json.loads(raw_map)
                if not isinstance(parsed, dict) or not all(
                    isinstance(k, str) and isinstance(v, str) for k, v in parsed.items()
                ):
                    raise ValueError
                field_map = parsed
            except ValueError:
                raise ConfigError("WEBHOOK_FIELD_MAP must be a JSON object of strings") from None
        raw_min = env.get("MIN_DEPOSIT", "").strip()
        try:
            min_deposit = Decimal(raw_min) if raw_min else None
        except InvalidOperation:
            raise ConfigError("MIN_DEPOSIT must be a decimal number") from None
        api_keys = list(_csv(env.get("API_KEYS", "")))
        legacy_key = env.get("BOT_API_KEY", "").strip()  # backward compatibility with the old server
        if legacy_key and legacy_key not in api_keys:
            api_keys.append(legacy_key)
        secret_key = env.get("SECRET_KEY", "")
        if not secret_key and environment != "production":
            secret_key = secrets.token_urlsafe(48)  # ephemeral, dev only
        try:
            settings = cls(
                environment=environment,
                database_url=env.get("DATABASE_URL", "sqlite+aiosqlite:///./dev.db").strip(),
                db_pool_size=int(env.get("DB_POOL_SIZE", "5")),
                db_max_overflow=int(env.get("DB_MAX_OVERFLOW", "5")),
                db_pool_timeout=int(env.get("DB_POOL_TIMEOUT", "30")),
                secret_key=secret_key,
                session_max_age=int(env.get("SESSION_MAX_AGE", "3600")),
                api_keys=tuple(api_keys),
                admin_username=env.get("ADMIN_USERNAME", "").strip(),
                admin_password_hash=env.get("ADMIN_PASSWORD_HASH", "").strip(),
                webhook_auth_mode=env.get("WEBHOOK_AUTH_MODE", "disabled").strip().lower(),
                webhook_secret=env.get("WEBHOOK_SECRET", ""),
                webhook_secret_header=env.get("WEBHOOK_SECRET_HEADER", "X-Webhook-Secret").strip(),
                webhook_signature_header=env.get("WEBHOOK_SIGNATURE_HEADER", "X-Webhook-Signature").strip(),
                webhook_methods=tuple(m.upper() for m in _csv(env.get("WEBHOOK_METHODS", "GET,POST"))),
                webhook_field_map=field_map,
                max_request_bytes=int(env.get("MAX_REQUEST_BYTES", "16384")),
                rate_limit_per_minute=int(env.get("RATE_LIMIT_PER_MINUTE", "60")),
                login_rate_limit_per_minute=int(env.get("LOGIN_RATE_LIMIT_PER_MINUTE", "5")),
                telegram_bot_token=env.get("TELEGRAM_BOT_TOKEN", "").strip(),
                admin_chat_ids=_csv(env.get("ADMIN_CHAT_IDS", "")),
                telegram_timeout=float(env.get("TELEGRAM_TIMEOUT", "10")),
                log_level=env.get("LOG_LEVEL", "INFO").strip().upper(),
                min_deposit=min_deposit,
                deposit_currency=env.get("DEPOSIT_CURRENCY", "USD").strip().upper() or "USD",
                trader_id_pattern=env.get("TRADER_ID_PATTERN", r"^[A-Za-z0-9_-]{3,32}$").strip(),
                affiliate_api_base_url=env.get("AFFILIATE_API_BASE_URL", "").strip(),
                affiliate_api_key=env.get("AFFILIATE_API_KEY", "").strip(),
            )
        except ValueError:
            raise ConfigError("a numeric environment variable has an invalid value") from None
        settings.validate()
        return settings


def _csv(value: str) -> tuple[str, ...]:
    return tuple(p.strip() for p in value.split(",") if p.strip())
