"""Verification logic + the affiliate-provider integration point.

IMPORTANT: no Quotex (or any broker) endpoint is invented here. `OfficialAffiliateProvider`
is a clearly-marked placeholder. Until you implement it against the broker's OFFICIAL
documentation and flip IMPLEMENTED to True, every verification returns "not_operational"
and no deposit data is ever produced.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import Protocol

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import Settings
from app.models import Deposit, TraderRecord, VerificationEvent, VerificationStatus, utcnow

log = logging.getLogger(__name__)

CENTS = Decimal("0.01")


# ----------------------------------------------------------------------------
# Provider contract
# ----------------------------------------------------------------------------
class ProviderNotOperational(Exception):
    """The affiliate integration is not implemented/configured."""


class InvalidTraderId(ValueError):
    pass


@dataclass(frozen=True)
class ProviderDeposit:
    provider_deposit_id: str  # stable unique ID from the official API (needed for de-duplication)
    amount: Decimal
    currency: str
    deposited_at: datetime | None = None


@dataclass(frozen=True)
class TraderLookup:
    found: bool   # the account exists / is registered
    linked: bool  # the account is attributed to OUR affiliate account
    deposits: list[ProviderDeposit] = field(default_factory=list)


class AffiliateProvider(Protocol):
    @property
    def operational(self) -> bool: ...

    async def lookup_trader(self, trader_id: str) -> TraderLookup: ...


class OfficialAffiliateProvider:
    """PLACEHOLDER for the broker's official affiliate API. NOT OPERATIONAL until implemented.

    To make it operational (only after you have official documentation + credentials):
      1. Implement `lookup_trader` using the documented endpoint(s) and auth scheme. It must
         return TraderLookup(found, linked, deposits) based ONLY on what the API returns.
      2. Every deposit needs a stable unique ID from the API (or a deterministic ID built from
         documented unique fields) so repeated checks never double-count or re-notify.
      3. Confirm with the API docs whether amounts are gross/net, whether demo/test accounts
         are excluded, and how refunds/chargebacks appear -- map them correctly.
      4. Test against a real account (see README), then set IMPLEMENTED = True.
    """

    IMPLEMENTED = False  # flip to True ONLY after real integration + testing

    def __init__(self, settings: Settings) -> None:
        self._base_url = settings.affiliate_api_base_url
        self._api_key = settings.affiliate_api_key

    @property
    def operational(self) -> bool:
        return self.IMPLEMENTED and bool(self._base_url and self._api_key)

    async def lookup_trader(self, trader_id: str) -> TraderLookup:
        if not self.operational:
            raise ProviderNotOperational("Affiliate API integration is not implemented/configured")
        # TODO: call the OFFICIAL affiliate API here (use httpx.AsyncClient, send credentials in
        # headers -- never in URLs -- and set timeouts). Do not guess endpoints or field names.
        raise NotImplementedError("Implement against the official affiliate API documentation")


def build_provider(settings: Settings) -> AffiliateProvider:
    return OfficialAffiliateProvider(settings)


def extract_trader_id(payload: dict) -> str | None:
    """PLACEHOLDER: map the affiliate platform's documented webhook field to a Trader ID.

    The webhook is used only as a *trigger*: we re-query the official API for the real data
    instead of trusting amounts inside the webhook body. Replace "trader_id" with the
    documented field name. (If the platform offers ONLY webhooks and no lookup API, the
    provider must be adapted to store webhook-supplied deposits -- see README.)
    """
    value = payload.get("trader_id")
    return str(value).strip() if value not in (None, "") else None


# ----------------------------------------------------------------------------
# Business rules
# ----------------------------------------------------------------------------
@dataclass
class VerificationOutcome:
    status: VerificationStatus
    trader_id: str
    message: str
    linked: bool = False
    deposit_total: Decimal | None = None
    currency: str | None = None
    user_notified: bool = False

    @property
    def verified(self) -> bool:
        return self.status is VerificationStatus.VERIFIED


def normalize_trader_id(raw: str, settings: Settings) -> str:
    value = (raw or "").strip()
    if not re.fullmatch(settings.trader_id_pattern, value):
        raise InvalidTraderId("Trader ID format is invalid")
    return value


def evaluate(lookup: TraderLookup, minimum: Decimal, currency: str) -> tuple[VerificationStatus, Decimal | None]:
    """Pure function: decide the status from REAL provider data. Never converts currencies."""
    if not lookup.found:
        return VerificationStatus.NOT_FOUND, None
    if not lookup.linked:
        return VerificationStatus.UNLINKED, None
    if not lookup.deposits:
        return VerificationStatus.LINKED_NO_DEPOSIT, Decimal("0.00")
    if any(d.currency.upper() != currency.upper() for d in lookup.deposits):
        return VerificationStatus.CURRENCY_REVIEW, None
    total = sum((d.amount for d in lookup.deposits), Decimal("0")).quantize(CENTS)
    if total < minimum:
        return VerificationStatus.BELOW_MINIMUM, total
    return VerificationStatus.VERIFIED, total


def _money(amount: Decimal, currency: str) -> str:
    return f"{amount:,.2f} {currency}"


def user_message(status: VerificationStatus, trader_id: str, total: Decimal | None, currency: str, minimum: Decimal) -> str:
    S = VerificationStatus
    if status is S.VERIFIED and total is not None:
        return f"✅ Verification successful. Trader ID {trader_id} is linked. Verified deposit: {_money(total, currency)}."
    if status is S.BELOW_MINIMUM and total is not None:
        return (f"Trader ID {trader_id} is linked, but your verified deposit is {_money(total, currency)}. "
                f"The minimum is {_money(minimum, currency)}.")
    messages = {
        S.LINKED_NO_DEPOSIT: f"Trader ID {trader_id} is linked, but no deposit has been found yet. "
                             f"Minimum deposit: {_money(minimum, currency)}.",
        S.UNLINKED: f"Trader ID {trader_id} exists but is not linked to our affiliate account. "
                    "Please contact support.",
        S.NOT_FOUND: f"Trader ID {trader_id} was not found. Please check it and try again.",
        S.ALREADY_CLAIMED: f"Trader ID {trader_id} is already linked to another Telegram account. "
                           "Please contact support.",
        S.CURRENCY_REVIEW: "Your deposit is in a currency that cannot be verified automatically. "
                           "An admin will review it.",
        S.ERROR: "Verification is temporarily unavailable. Please try again later.",
        S.NOT_OPERATIONAL: "Verification is not available yet. Please try again later.",
    }
    return messages[status]


def _event(session: AsyncSession, *, record_id: int | None, telegram_user_id: int, trader_id: str, source: str,
           status: VerificationStatus, linked: bool = False, total: Decimal | None = None,
           currency: str | None = None, detail: str | None = None) -> None:
    session.add(VerificationEvent(
        record_id=record_id, telegram_user_id=telegram_user_id, trader_id=trader_id, source=source,
        status=status.value, linked=linked, deposit_total=total, currency=currency, detail=detail,
    ))


async def verify_trader(
    *,
    session: AsyncSession,
    provider: AffiliateProvider,
    telegram,  # TelegramService (or test double)
    settings: Settings,
    telegram_user_id: int,
    trader_id: str,
    telegram_username: str | None = None,
    source: str = "bot",
    notify_user: bool = True,
) -> VerificationOutcome:
    trader_id = normalize_trader_id(trader_id, settings)
    currency = settings.deposit_currency.upper()
    minimum = settings.min_deposit if settings.min_deposit is not None else Decimal("0")

    def outcome(status: VerificationStatus, *, linked: bool = False, total: Decimal | None = None) -> VerificationOutcome:
        return VerificationOutcome(
            status=status, trader_id=trader_id, linked=linked, deposit_total=total,
            currency=currency, message=user_message(status, trader_id, total, currency, minimum),
        )

    async def notify(result: VerificationOutcome) -> VerificationOutcome:
        if not notify_user:
            return result
        if source == "bot":  # the user just asked: always answer
            result.user_notified = await telegram.send_text(telegram_user_id, result.message)
        else:                # system-triggered: never repeat an identical state
            key = f"user:{trader_id}:{result.status.value}:{result.deposit_total}"
            result.user_notified = await telegram.send_once(key, telegram_user_id, result.message)
        return result

    if not provider.operational or not settings.verification_configured:
        log.warning("Verification requested but the affiliate provider / MIN_DEPOSIT is NOT operational")
        return outcome(VerificationStatus.NOT_OPERATIONAL)

    record = (await session.execute(
        select(TraderRecord).where(TraderRecord.trader_id == trader_id)
    )).scalar_one_or_none()

    # One Trader ID can belong to only one Telegram user.
    if record is not None and record.telegram_user_id != telegram_user_id:
        _event(session, record_id=record.id, telegram_user_id=telegram_user_id, trader_id=trader_id,
               source=source, status=VerificationStatus.ALREADY_CLAIMED)
        await session.commit()
        await telegram.send_once_admins(
            f"admin:claim-conflict:{trader_id}:{telegram_user_id}",
            f"⚠️ Trader ID {trader_id} (bound to Telegram {record.telegram_user_id}) "
            f"was submitted by another Telegram user: {telegram_user_id}.",
        )
        return await notify(outcome(VerificationStatus.ALREADY_CLAIMED))

    try:
        lookup = await provider.lookup_trader(trader_id)
    except ProviderNotOperational:
        return outcome(VerificationStatus.NOT_OPERATIONAL)
    except Exception as exc:  # network/API failure: log the type only (messages may contain URLs)
        log.error("Affiliate lookup failed for trader %s: %s", trader_id, type(exc).__name__)
        _event(session, record_id=record.id if record else None, telegram_user_id=telegram_user_id,
               trader_id=trader_id, source=source, status=VerificationStatus.ERROR, detail=type(exc).__name__)
        await session.commit()
        result = outcome(VerificationStatus.ERROR)
        return await notify(result) if source == "bot" else result

    status, total = evaluate(lookup, minimum, currency)
    is_linked = lookup.found and lookup.linked
    now = utcnow()

    if is_linked:
        if record is None:
            record = TraderRecord(trader_id=trader_id, telegram_user_id=telegram_user_id,
                                  telegram_username=telegram_username, status=status.value, linked=True)
            session.add(record)
        if telegram_username:
            record.telegram_username = telegram_username
        record.status = status.value
        record.linked = True
        record.deposit_total = total
        record.currency = currency if total is not None else record.currency
        record.last_checked_at = now
        if status is VerificationStatus.VERIFIED and record.verified_at is None:
            record.verified_at = now
        try:
            await session.flush()
        except IntegrityError:  # two simultaneous first-time requests for the same Trader ID
            await session.rollback()
            log.warning("Concurrent verification race for trader %s", trader_id)
            return await notify(outcome(VerificationStatus.ERROR)) if source == "bot" else outcome(VerificationStatus.ERROR)

        known = set((await session.execute(
            select(Deposit.provider_deposit_id).where(Deposit.record_id == record.id)
        )).scalars())
        for d in lookup.deposits:
            if d.provider_deposit_id not in known:
                known.add(d.provider_deposit_id)
                session.add(Deposit(record_id=record.id, provider_deposit_id=d.provider_deposit_id,
                                    amount=d.amount, currency=d.currency.upper(), deposited_at=d.deposited_at))

    _event(session, record_id=record.id if record else None, telegram_user_id=telegram_user_id,
           trader_id=trader_id, source=source, status=status, linked=is_linked, total=total,
           currency=currency if total is not None else None)
    await session.commit()

    # ---- Notifications (after the data is safely committed) ----
    if is_linked:
        who = f"{telegram_user_id}" + (f" (@{record.telegram_username})" if record.telegram_username else "")
        if status is VerificationStatus.VERIFIED and total is not None:
            sent = await telegram.send_once_admins(
                f"admin:verified:{trader_id}",
                f"✅ New verified account\nTrader ID: {trader_id}\nTelegram: {who}\n"
                f"Verified deposit total: {_money(total, currency)} (minimum {_money(minimum, currency)})",
            )
            if sent:  # this message already covers the existing deposits
                for d in lookup.deposits:
                    await telegram.mark_sent_admins(f"admin:deposit:{trader_id}:{d.provider_deposit_id}")
        for d in lookup.deposits:  # de-duplicated per deposit; failed sends are retried on the next check
            await telegram.send_once_admins(
                f"admin:deposit:{trader_id}:{d.provider_deposit_id}",
                f"💰 New deposit\nTrader ID: {trader_id}\nTelegram: {who}\n"
                f"Amount: {_money(d.amount, d.currency.upper())}"
                + (f"\nVerified total: {_money(total, currency)}" if total is not None else ""),
            )

    return await notify(outcome(status, linked=is_linked, total=total))


async def recheck_trader(*, session: AsyncSession, provider: AffiliateProvider, telegram,
                         settings: Settings, trader_id: str) -> VerificationOutcome | None:
    """Re-verify a known Trader ID (used by the webhook). Returns None for unknown IDs."""
    trader_id = normalize_trader_id(trader_id, settings)
    record = (await session.execute(
        select(TraderRecord).where(TraderRecord.trader_id == trader_id)
    )).scalar_one_or_none()
    if record is None:
        return None
    return await verify_trader(
        session=session, provider=provider, telegram=telegram, settings=settings,
        telegram_user_id=record.telegram_user_id, telegram_username=record.telegram_username,
        trader_id=trader_id, source="webhook",
    )
