"""Public API routes: health, events, and the affiliate webhook receiver."""
from __future__ import annotations

import json
import logging
from datetime import date
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Path, Query, Request, Response
from fastapi.responses import JSONResponse
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from app import event_service, verification_service as vs, webhook_service
from app.database import get_session
from app.logging_config import log_event
from app.models import TraderRecord, VerificationStatus
from app.schemas import EventIn, VerifyRequest, sanitize_errors
from app.security import client_ip, verify_api_key

logger = logging.getLogger(__name__)
router = APIRouter()

EVENT_ID_PATH = Path(pattern=r"^[A-Za-z0-9_.:\-]{1,128}$")


def _rate_limit(request: Request, bucket: str) -> None:
    state = request.app.state
    if not state.limiter.allow(f"{bucket}:{client_ip(request)}", state.settings.rate_limit_per_minute):
        raise HTTPException(429, "Too many requests", headers={"Retry-After": "60"})


async def require_api_access(request: Request, x_api_key: Optional[str] = Header(default=None)) -> None:
    _rate_limit(request, "api")
    if not verify_api_key(x_api_key, request.app.state.settings.api_keys):
        raise HTTPException(401, "Unauthorized", headers={"WWW-Authenticate": "ApiKey"})


def _verification_operational(request: Request) -> bool:
    state = request.app.state
    return bool(state.provider.operational and state.settings.verification_configured)


def _db_unavailable(where: str, exc: Exception) -> HTTPException:
    log_event(logger, logging.ERROR, "database_error", where=where, error=type(exc).__name__)
    return HTTPException(503, "Service temporarily unavailable")


# ------------------------------------------------------------------ health


@router.get("/health")
async def health(request: Request) -> dict:
    """Liveness probe: process is up. Does not touch the database.

    `verification_operational` is kept from the old server (the bot may read it); it is False until
    the official affiliate API is implemented AND MIN_DEPOSIT is configured.
    """
    return {"status": "ok", "verification_operational": _verification_operational(request)}


@router.get("/api/v1/health")
async def health_v1(request: Request):
    """Readiness probe: includes database connectivity. Exposes no sensitive data."""
    db_ok = await request.app.state.db.ping()
    body = {"status": "ok" if db_ok else "degraded", "database": "up" if db_ok else "down"}
    return JSONResponse(body, status_code=200 if db_ok else 503)


# ------------------------------------------------------------------ events


@router.post("/api/v1/events", dependencies=[Depends(require_api_access)])
async def create_event(
    data: EventIn, request: Request, response: Response, session: AsyncSession = Depends(get_session)
) -> dict:
    state = request.app.state
    try:
        result = await event_service.process_event(session, state.telegram, data, source="api")
    except SQLAlchemyError as exc:
        raise _db_unavailable("create_event", exc) from None
    response.status_code = 201 if result.created else 200
    return {"event": result.event, "duplicate": not result.created, "notification": result.notification}


@router.get("/api/v1/events", dependencies=[Depends(require_api_access)])
async def list_events(
    q: Optional[str] = Query(default=None, pattern=r"^[A-Za-z0-9_.:\-]{1,128}$"),
    event_name: Optional[str] = Query(default=None, pattern=r"^[A-Za-z0-9_.:\-]{1,64}$"),
    status: Optional[str] = Query(default=None, pattern=r"^(received|processed|failed)$"),
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    limit: int = Query(default=25, ge=1, le=100),
    offset: int = Query(default=0, ge=0, le=1_000_000),
    session: AsyncSession = Depends(get_session),
) -> dict:
    try:
        rows, total = await event_service.list_events(
            session, q=q, event_name=event_name, status=status,
            date_from=date_from, date_to=date_to, limit=limit, offset=offset,
        )
    except SQLAlchemyError as exc:
        raise _db_unavailable("list_events", exc) from None
    return {"total": total, "limit": limit, "offset": offset, "items": [event_service.event_to_dict(e) for e in rows]}


@router.get("/api/v1/events/{event_id}", dependencies=[Depends(require_api_access)])
async def get_event(event_id: str = EVENT_ID_PATH, session: AsyncSession = Depends(get_session)) -> dict:
    try:
        event = await event_service.get_event(session, event_id)
    except SQLAlchemyError as exc:
        raise _db_unavailable("get_event", exc) from None
    if event is None:
        raise HTTPException(404, "Event not found")
    return event_service.event_to_dict(event)


# ------------------------------------------------------------------ webhook


@router.api_route("/webhooks/affiliate", methods=["GET", "POST"])
async def affiliate_webhook(request: Request, session: AsyncSession = Depends(get_session)):
    state = request.app.state
    settings = state.settings
    _rate_limit(request, "webhook")
    if request.method not in settings.webhook_methods:
        raise HTTPException(405, "Method not allowed")
    if settings.webhook_auth_mode == "disabled":
        # No verified provider authentication mechanism is configured: refuse to process.
        raise HTTPException(503, "Webhook processing is not enabled")

    body = await request.body() if request.method == "POST" else b""
    query = request.scope.get("query_string", b"")
    if not webhook_service.verify_authentication(settings, request.headers, request.method, query, body):
        log_event(logger, logging.WARNING, "webhook_unauthorized", ip=client_ip(request))
        raise HTTPException(401, "Unauthorized")

    try:
        raw = webhook_service.parse_payload(
            request.method, request.headers.get("content-type", ""), query, body
        )
    except webhook_service.PayloadError as exc:
        raise HTTPException(exc.status, exc.message) from None
    try:
        data = webhook_service.build_event(raw, settings.webhook_field_map)
    except ValidationError as exc:
        log_event(
            logger, logging.WARNING, "webhook_invalid_payload",
            ignored_fields=webhook_service.ignored_field_count(raw, settings.webhook_field_map),
        )
        return JSONResponse({"detail": sanitize_errors(exc.errors())}, status_code=422)

    try:
        result = await event_service.process_event(session, state.telegram, data, source="webhook")
    except SQLAlchemyError as exc:
        raise _db_unavailable("webhook", exc) from None
    return {"status": "accepted", "duplicate": not result.created, "event_id": data.event_id}


# ------------------------------------------------------------ verification
# Ported from the old verification server; paths and JSON shapes are unchanged.


def _verify_body(o: vs.VerificationOutcome, minimum: Optional[Decimal]) -> dict:
    return {
        "status": o.status.value,
        "verified": o.verified,
        "linked": o.linked,
        "trader_id": o.trader_id,
        "verified_deposit_total": f"{o.deposit_total:.2f}" if o.deposit_total is not None else None,
        "currency": o.currency,
        "minimum_deposit": f"{minimum:.2f}" if minimum is not None else None,
        "message": o.message,
        "user_notified": o.user_notified,
    }


def trader_row(r: TraderRecord) -> dict:
    fmt = lambda d: d.strftime("%Y-%m-%d %H:%M:%S UTC") if d else "-"  # noqa: E731
    return {
        "trader_id": r.trader_id, "telegram_user_id": r.telegram_user_id,
        "telegram_username": r.telegram_username, "status": r.status, "linked": r.linked,
        "verified_deposit_total": f"{r.deposit_total:.2f}" if r.deposit_total is not None else None,
        "currency": r.currency, "verified_at": fmt(r.verified_at), "last_checked_at": fmt(r.last_checked_at),
    }


@router.post("/api/v1/verify", dependencies=[Depends(require_api_access)])
async def verify(body: VerifyRequest, request: Request, session: AsyncSession = Depends(get_session)):
    state = request.app.state
    try:
        outcome = await vs.verify_trader(
            session=session, provider=state.provider, telegram=state.telegram, settings=state.settings,
            telegram_user_id=body.telegram_user_id, telegram_username=body.telegram_username,
            trader_id=body.trader_id, source="bot", notify_user=body.notify_user,
        )
    except vs.InvalidTraderId as exc:
        raise HTTPException(422, str(exc)) from None
    except SQLAlchemyError as exc:
        raise _db_unavailable("verify", exc) from None
    code = {VerificationStatus.NOT_OPERATIONAL: 503, VerificationStatus.ERROR: 502}.get(outcome.status, 200)
    return JSONResponse(_verify_body(outcome, state.settings.min_deposit), status_code=code)


@router.get("/api/v1/status/{trader_id}", dependencies=[Depends(require_api_access)])
async def stored_status(trader_id: str = EVENT_ID_PATH, session: AsyncSession = Depends(get_session)):
    try:
        rec = (await session.execute(select(TraderRecord).where(TraderRecord.trader_id == trader_id))).scalar_one_or_none()
    except SQLAlchemyError as exc:
        raise _db_unavailable("status", exc) from None
    if rec is None:
        raise HTTPException(404, "No stored verification for this Trader ID")
    return trader_row(rec)


@router.post("/webhooks/affiliate/verify", status_code=202)
async def affiliate_verify_trigger(request: Request, session: AsyncSession = Depends(get_session)):
    """Old server's webhook (re-verify a known Trader ID), moved from /webhooks/affiliate because the new
    event-tracking receiver owns that path. The payload is only a TRIGGER: real data is re-fetched from the
    official affiliate API. Uses the same configured webhook authentication (header/hmac); the old
    `?token=` query parameter was dropped because secrets in URLs end up in infrastructure logs."""
    state = request.app.state
    settings = state.settings
    _rate_limit(request, "webhook")
    if settings.webhook_auth_mode == "disabled":
        raise HTTPException(503, "Webhook processing is not enabled")
    body = await request.body()
    query = request.scope.get("query_string", b"")
    if not webhook_service.verify_authentication(settings, request.headers, "POST", query, body):
        log_event(logger, logging.WARNING, "webhook_unauthorized", ip=client_ip(request))
        raise HTTPException(401, "Unauthorized")
    if not (state.provider.operational and settings.verification_configured):
        raise HTTPException(503, "Affiliate integration is not operational")
    try:
        payload = json.loads(body)
    except (ValueError, RecursionError):
        raise HTTPException(400, "Body must be JSON") from None
    trader_id = vs.extract_trader_id(payload) if isinstance(payload, dict) else None
    if not trader_id:
        return {"status": "ignored", "reason": "no trader id in payload"}
    try:
        outcome = await vs.recheck_trader(
            session=session, provider=state.provider, telegram=state.telegram, settings=settings, trader_id=trader_id
        )
    except vs.InvalidTraderId:
        return {"status": "ignored", "reason": "invalid trader id"}
    except SQLAlchemyError as exc:
        raise _db_unavailable("verify_webhook", exc) from None
    if outcome is None:
        return {"status": "ignored", "reason": "unknown trader id"}
    return {"status": outcome.status.value}
