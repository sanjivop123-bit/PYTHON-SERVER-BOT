"""Authentication helpers, rate limiting and ASGI security middleware."""
from __future__ import annotations

import hmac
import json
import secrets
import time
from collections import deque

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError
from fastapi import Request
from starlette.datastructures import MutableHeaders

_hasher = PasswordHasher()
MAX_PASSWORD_LENGTH = 256


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    if not password_hash or len(password) > MAX_PASSWORD_LENGTH:
        return False
    try:
        return _hasher.verify(password_hash, password)
    except (VerificationError, InvalidHashError):
        return False


def verify_api_key(provided: str | None, valid_keys: tuple[str, ...]) -> bool:
    if not provided or not valid_keys:
        return False
    ok = False
    for key in valid_keys:  # compare against all keys, constant time per key
        ok |= hmac.compare_digest(provided.encode(), key.encode())
    return ok


def new_csrf_token() -> str:
    return secrets.token_urlsafe(32)


def client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


class RateLimiter:
    """In-memory sliding-window limiter (per instance; see SECURITY.md for limits)."""

    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = {}

    def allow(self, key: str, limit: int, window: float = 60.0, now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now
        if len(self._hits) > 10000:
            self._hits = {k: v for k, v in self._hits.items() if v and now - v[-1] < window}
        q = self._hits.setdefault(key, deque())
        while q and now - q[0] >= window:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(now)
        return True


# ---------------------------------------------------------------- middleware


async def _json_response(send, status: int, detail: str, extra_headers=()) -> None:
    body = json.dumps({"detail": detail}).encode()
    headers = [(b"content-type", b"application/json"), (b"content-length", str(len(body)).encode())]
    headers.extend(extra_headers)
    await send({"type": "http.response.start", "status": status, "headers": headers})
    await send({"type": "http.response.body", "body": body})


class _TooLarge(Exception):
    pass


class BodySizeLimitMiddleware:
    """Rejects oversized bodies (Content-Length and streamed) and oversized query strings."""

    def __init__(self, app, max_bytes: int, max_query_bytes: int = 8192) -> None:
        self.app, self.max_bytes, self.max_query_bytes = app, max_bytes, max_query_bytes

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        if len(scope.get("query_string", b"")) > self.max_query_bytes:
            return await _json_response(send, 414, "Query string too long")
        headers = dict(scope["headers"])
        raw_len = headers.get(b"content-length")
        if raw_len is not None:
            try:
                if int(raw_len) > self.max_bytes:
                    return await _json_response(send, 413, "Request body too large")
            except ValueError:
                return await _json_response(send, 400, "Invalid Content-Length")

        received = 0
        started = False

        async def limited_receive():
            nonlocal received
            message = await receive()
            if message["type"] == "http.request":
                received += len(message.get("body", b""))
                if received > self.max_bytes:
                    raise _TooLarge
            return message

        async def tracking_send(message):
            nonlocal started
            if message["type"] == "http.response.start":
                started = True
            await send(message)

        try:
            await self.app(scope, limited_receive, tracking_send)
        except _TooLarge:
            if not started:
                await _json_response(send, 413, "Request body too large")


class HTTPSOnlyMiddleware:
    """Rejects plain-HTTP requests (scheme is derived from X-Forwarded-Proto by uvicorn)."""

    def __init__(self, app, enabled: bool) -> None:
        self.app, self.enabled = app, enabled

    async def __call__(self, scope, receive, send):
        if self.enabled and scope["type"] == "http" and scope["path"] != "/health":
            if scope.get("scheme") != "https":
                return await _json_response(send, 400, "HTTPS is required")
        await self.app(scope, receive, send)


class SecurityHeadersMiddleware:
    def __init__(self, app, hsts: bool) -> None:
        self.app, self.hsts = app, hsts

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        async def send_with_headers(message):
            if message["type"] == "http.response.start":
                h = MutableHeaders(scope=message)
                h["X-Content-Type-Options"] = "nosniff"
                h["X-Frame-Options"] = "DENY"
                h["Referrer-Policy"] = "no-referrer"
                h["Content-Security-Policy"] = (
                    "default-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'"
                )
                if not scope["path"].startswith("/static"):
                    h["Cache-Control"] = "no-store"
                if self.hsts:
                    h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
            await send(message)

        await self.app(scope, receive, send_with_headers)
