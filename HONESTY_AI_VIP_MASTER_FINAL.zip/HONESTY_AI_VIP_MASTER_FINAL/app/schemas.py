"""Input validation schemas. Only documented, non-sensitive tracking fields are accepted."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated, Optional

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, field_validator

IdStr = Annotated[str, StringConstraints(pattern=r"^[A-Za-z0-9_.:\-]{1,128}$")]
NameStr = Annotated[str, StringConstraints(pattern=r"^[A-Za-z0-9_.:\-]{1,64}$")]


class EventIn(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    event_id: IdStr
    event_name: NameStr
    click_id: Optional[IdStr] = None
    site_id: Optional[IdStr] = None
    link_id: Optional[IdStr] = None
    event_timestamp: Optional[datetime] = None

    @field_validator("event_name")
    @classmethod
    def _lower_name(cls, v: str) -> str:
        return v.lower()

    @field_validator("event_timestamp")
    @classmethod
    def _utc(cls, v: Optional[datetime]) -> Optional[datetime]:
        if v is None:
            return None
        return v.replace(tzinfo=timezone.utc) if v.tzinfo is None else v.astimezone(timezone.utc)


def sanitize_errors(errors) -> list[dict]:
    """Return validation errors without echoing submitted values."""
    return [
        {"loc": [str(p) for p in e.get("loc", ())], "msg": str(e.get("msg", "invalid"))}
        for e in errors
    ]


class VerifyRequest(BaseModel):
    """Body of POST /api/v1/verify (unchanged from the old server)."""

    model_config = ConfigDict(str_strip_whitespace=True)  # extras ignored, as in the old server

    telegram_user_id: int = Field(gt=0)
    trader_id: str = Field(min_length=1, max_length=64)
    telegram_username: Optional[str] = Field(default=None, max_length=64)
    notify_user: bool = True
