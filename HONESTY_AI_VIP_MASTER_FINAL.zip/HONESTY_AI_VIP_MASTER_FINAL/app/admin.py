"""Admin dashboard: session auth, CSRF protection, rate-limited login."""
from __future__ import annotations

import hmac
import logging
from datetime import date
from pathlib import Path
from typing import Optional
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, or_, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from app import event_service
from app.api import trader_row
from app.models import TraderRecord, VerificationEvent, VerificationStatus
from app.database import get_session
from app.logging_config import log_event
from app.security import client_ip, new_csrf_token, verify_password
from app.webhook_service import PayloadError, parse_urlencoded

logger = logging.getLogger(__name__)
router = APIRouter(include_in_schema=False)
templates = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))  # autoescape on
PAGE_SIZE = 25


def _csrf(request: Request) -> str:
    token = request.session.get("csrf")
    if not token:
        token = new_csrf_token()
        request.session["csrf"] = token
    return token


def _csrf_ok(request: Request, supplied: str) -> bool:
    expected = request.session.get("csrf")
    return bool(expected) and bool(supplied) and hmac.compare_digest(expected.encode(), supplied.encode())


def _is_admin(request: Request) -> bool:
    return request.session.get("admin") is True


def _login_page(request: Request, error: str = "", status_code: int = 200):
    return templates.TemplateResponse(
        request, "login.html", {"csrf_token": _csrf(request), "error": error}, status_code=status_code
    )


@router.get("/admin/login")
async def login_form(request: Request):
    if _is_admin(request):
        return RedirectResponse("/admin", status_code=303)
    return _login_page(request)


@router.post("/admin/login")
async def login_submit(request: Request):
    state = request.app.state
    settings = state.settings
    ip = client_ip(request)
    if not state.limiter.allow(f"login:{ip}", settings.login_rate_limit_per_minute):
        log_event(logger, logging.WARNING, "admin_login_rate_limited", ip=ip)
        return _login_page(request, "Too many attempts. Try again in a minute.", 429)
    if not settings.admin_configured:
        return _login_page(request, "Admin login is not configured.", 503)
    try:
        form = parse_urlencoded(await request.body())
    except PayloadError:
        return _login_page(request, "Invalid request.", 400)
    if not _csrf_ok(request, form.get("csrf_token", "")):
        return _login_page(request, "Session expired. Please try again.", 403)
    user_ok = hmac.compare_digest(form.get("username", "").encode(), settings.admin_username.encode())
    pass_ok = verify_password(settings.admin_password_hash, form.get("password", ""))  # always evaluated
    if user_ok and pass_ok:
        request.session.clear()
        request.session["admin"] = True
        request.session["csrf"] = new_csrf_token()
        log_event(logger, logging.INFO, "admin_login_success", ip=ip)
        return RedirectResponse("/admin", status_code=303)
    log_event(logger, logging.WARNING, "admin_login_failed", ip=ip)
    return _login_page(request, "Invalid username or password.", 401)


@router.post("/admin/logout")
async def logout(request: Request):
    try:
        form = parse_urlencoded(await request.body())
    except PayloadError:
        form = {}
    if _is_admin(request) and _csrf_ok(request, form.get("csrf_token", "")):
        request.session.clear()
    return RedirectResponse("/admin/login", status_code=303)


def _parse_date(value: str) -> Optional[date]:
    try:
        return date.fromisoformat(value) if value else None
    except ValueError:
        return None


@router.get("/admin")
async def dashboard(
    request: Request,
    q: str = Query(default="", max_length=128),
    event_name: str = Query(default="", max_length=64),
    status: str = Query(default="", max_length=16),
    date_from: str = Query(default="", max_length=10),
    date_to: str = Query(default="", max_length=10),
    page: int = Query(default=1, ge=1, le=100000),
    session: AsyncSession = Depends(get_session),
):
    if not _is_admin(request):
        return RedirectResponse("/admin/login", status_code=303)
    state = request.app.state
    d_from, d_to = _parse_date(date_from), _parse_date(date_to)
    errors = []
    if date_from and d_from is None:
        errors.append("Invalid 'from' date (use YYYY-MM-DD).")
    if date_to and d_to is None:
        errors.append("Invalid 'to' date (use YYYY-MM-DD).")
    status_filter = status if status in {"received", "processed", "failed"} else ""
    db_ok = await state.db.ping()
    traders, vhistory, verified_count = [], [], 0
    events, total, stats, names = [], 0, {"total": 0, "processed": 0, "failed": 0, "notifications": {}}, []
    if db_ok:
        try:
            rows, total = await event_service.list_events(
                session,
                q=q if _safe_q(q) else None,
                event_name=event_name or None,
                status=status_filter or None,
                date_from=d_from,
                date_to=d_to,
                limit=PAGE_SIZE,
                offset=(page - 1) * PAGE_SIZE,
            )
            events = [event_service.event_to_dict(e) for e in rows]
            stats = await event_service.get_stats(session)
            names = await event_service.distinct_event_names(session)
            traders = [trader_row(u) for u in await _traders(session, q)]
            vhistory = [_vevent_row(e) for e in await _vevents(session, q)]
            verified_count = (await session.execute(
                select(func.count()).select_from(TraderRecord)
                .where(TraderRecord.status == VerificationStatus.VERIFIED.value)
            )).scalar_one()
        except SQLAlchemyError as exc:
            db_ok = False
            log_event(logger, logging.ERROR, "database_error", where="dashboard", error=type(exc).__name__)
    base = {"q": q, "event_name": event_name, "status": status_filter, "date_from": date_from, "date_to": date_to}
    base = {k: v for k, v in base.items() if v}
    prev_url = "/admin?" + urlencode({**base, "page": page - 1}) if page > 1 else None
    next_url = "/admin?" + urlencode({**base, "page": page + 1}) if page * PAGE_SIZE < total else None
    return templates.TemplateResponse(
        request,
        "admin.html",
        {
            "csrf_token": _csrf(request),
            "events": events,
            "total_filtered": total,
            "stats": stats,
            "event_names": names,
            "filters": {"q": q, "event_name": event_name, "status": status_filter,
                        "date_from": date_from, "date_to": date_to},
            "errors": errors,
            "traders": traders,
            "vhistory": vhistory,
            "verified_count": verified_count,
            "verification_operational": bool(state.provider.operational and state.settings.verification_configured),
            "page": page,
            "prev_url": prev_url,
            "next_url": next_url,
            "health": {
                "server": "ok",
                "database": "up" if db_ok else "down",
                "telegram": "configured" if state.telegram.configured else "NOT CONFIGURED",
                "webhook": "enabled" if settings_webhook_enabled(state.settings) else "DISABLED",
            },
        },
    )


def _vevent_row(e: VerificationEvent) -> dict:
    fmt = lambda d: d.strftime("%Y-%m-%d %H:%M:%S UTC") if d else "-"  # noqa: E731
    return {
        "time": fmt(e.created_at), "trader_id": e.trader_id, "telegram_user_id": e.telegram_user_id,
        "source": e.source, "status": e.status, "linked": e.linked,
        "verified_deposit_total": f"{e.deposit_total:.2f}" if e.deposit_total is not None else None,
        "currency": e.currency, "detail": e.detail,
    }


async def _traders(session: AsyncSession, q: str) -> list[TraderRecord]:
    stmt = select(TraderRecord).order_by(TraderRecord.created_at.desc()).limit(200)
    if q:
        stmt = stmt.where(or_(TraderRecord.trader_id.contains(q, autoescape=True),
                              TraderRecord.telegram_username.contains(q, autoescape=True)))
    return list((await session.execute(stmt)).scalars())


async def _vevents(session: AsyncSession, q: str) -> list[VerificationEvent]:
    stmt = select(VerificationEvent).order_by(VerificationEvent.created_at.desc(), VerificationEvent.id.desc()).limit(200)
    if q:
        stmt = stmt.where(VerificationEvent.trader_id.contains(q, autoescape=True))
    return list((await session.execute(stmt)).scalars())


@router.get("/admin/api/users")
async def admin_users(request: Request, q: str = Query(default="", max_length=64),
                      session: AsyncSession = Depends(get_session)):
    if not _is_admin(request):
        raise HTTPException(401, "Unauthorized")
    return JSONResponse([trader_row(u) for u in await _traders(session, q)])


@router.get("/admin/api/history")
async def admin_history(request: Request, q: str = Query(default="", max_length=64),
                        session: AsyncSession = Depends(get_session)):
    if not _is_admin(request):
        raise HTTPException(401, "Unauthorized")
    return JSONResponse([_vevent_row(e) for e in await _vevents(session, q)])


def _safe_q(q: str) -> bool:
    import re

    return bool(re.fullmatch(r"[A-Za-z0-9_.:\-]{1,128}", q or ""))


def settings_webhook_enabled(settings) -> bool:
    return settings.webhook_auth_mode != "disabled"
