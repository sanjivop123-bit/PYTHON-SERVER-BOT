"""Telegram admin notifications.

Only calls sendMessage. It never calls getUpdates, setWebhook or deleteWebhook, so the
existing bot and its webhook/polling setup are untouched. The bot token is never logged.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Optional

import httpx
from sqlalchemy import delete
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.logging_config import log_event
from app.models import NotificationLog

logger = logging.getLogger(__name__)
API_BASE = "https://api.telegram.org"


class TelegramError(Exception):
    """Carries only a short, non-sensitive reason code."""


class TelegramService:
    def __init__(self, bot_token: str, chat_ids: tuple[str, ...], timeout: float = 10.0, transport=None) -> None:
        self._token = bot_token or ""
        self.chat_ids = tuple(chat_ids)
        # Set by create_app(); needed by send_once/mark_sent (own short sessions, safe across instances).
        self.session_factory = None
        self._client: Optional[httpx.AsyncClient] = (
            httpx.AsyncClient(timeout=timeout, transport=transport) if self.configured else None
        )

    def __repr__(self) -> str:  # never expose the token
        return f"TelegramService(configured={self.configured})"

    @property
    def configured(self) -> bool:
        return bool(self._token and self.chat_ids)

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()

    async def send_message(self, chat_id: str, text: str) -> None:
        if self._client is None:
            raise TelegramError("not_configured")
        url = f"{API_BASE}/bot{self._token}/sendMessage"
        try:
            resp = await self._client.post(
                url, json={"chat_id": chat_id, "text": text, "disable_web_page_preview": True}
            )
        except httpx.HTTPError:
            raise TelegramError("network_error") from None  # `from None`: exception text may contain the URL
        if resp.status_code != 200:
            raise TelegramError(f"http_{resp.status_code}")
        try:
            ok = resp.json().get("ok") is True
        except ValueError:
            ok = False
        if not ok:
            raise TelegramError("api_not_ok")

    @staticmethod
    def format_event_message(event_name: str, event_id: str, processed_at: datetime) -> str:
        return (
            "HONESTY AI VIP SERVER\n\n"
            f"Event Received: {event_name.replace('_', ' ').title()}\n"
            f"Event ID: {event_id}\n"
            "Processing: Successful\n"
            f"Timestamp: {processed_at.strftime('%Y-%m-%d %H:%M:%S')} UTC"
        )

    async def notify_event(
        self, session: AsyncSession, event_id: str, event_name: str, processed_at: datetime
    ) -> str:
        """Send one notification per (event, chat). Returns sent/failed/partial/duplicate/not_configured."""
        if not self.configured:
            return "not_configured"
        text = self.format_event_message(event_name, event_id, processed_at)
        results: list[str] = []
        for chat_id in self.chat_ids:
            key = f"event:{event_id}:{chat_id}"
            entry = NotificationLog(dedupe_key=key, chat_id=chat_id, notification_status="pending")
            session.add(entry)
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()
                results.append("duplicate")
                continue
            try:
                await self.send_message(chat_id, text)
                status = "sent"
            except TelegramError as exc:
                status = "failed"
                log_event(logger, logging.WARNING, "telegram_send_failed", reason=str(exc))
            entry.notification_status = status
            await session.commit()
            results.append(status)
        if all(r == "duplicate" for r in results):
            return "duplicate"
        if all(r in ("sent", "duplicate") for r in results):
            return "sent"
        if any(r == "sent" for r in results):
            return "partial"
        return "failed"

    # ------------------------------------------------------------------
    # Ported from the old verification server: boolean send + de-duplication.
    # ------------------------------------------------------------------
    async def send_text(self, chat_id: int | str, text: str) -> bool:
        """Send a plain-text message. Returns True on success. Never raises."""
        if not self.configured or not str(chat_id):
            logger.warning("telegram_not_configured_or_empty_chat")
            return False
        try:
            await self.send_message(str(chat_id), text)
            return True
        except TelegramError as exc:
            log_event(logger, logging.WARNING, "telegram_send_failed", reason=str(exc))
            return False

    async def send_once(self, dedupe_key: str, chat_id: int | str, text: str) -> bool:
        """Send only if `dedupe_key` was never used. True only when a message was actually sent.

        The key is reserved first (unique constraint => safe across Cloud Run instances) and
        released again if delivery fails, so a later attempt can retry.
        """
        if self.session_factory is None:
            raise RuntimeError("TelegramService.session_factory is not set")
        dedupe_key = dedupe_key[:250]
        async with self.session_factory() as session:
            session.add(NotificationLog(dedupe_key=dedupe_key, chat_id=str(chat_id), notification_status="pending"))
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()
                return False
        sent = await self.send_text(chat_id, text)
        async with self.session_factory() as session:
            if sent:
                await session.execute(
                    NotificationLog.__table__.update()
                    .where(NotificationLog.dedupe_key == dedupe_key)
                    .values(notification_status="sent")
                )
            else:
                await session.execute(delete(NotificationLog).where(NotificationLog.dedupe_key == dedupe_key))
            await session.commit()
        return sent

    async def send_once_admins(self, dedupe_key: str, text: str) -> bool:
        """send_once to every configured admin chat; True if at least one message was sent."""
        results = [await self.send_once(f"{dedupe_key}:{c}", c, text) for c in self.chat_ids]
        return any(results)

    async def mark_sent(self, dedupe_key: str) -> None:
        """Reserve a dedupe key without sending (another message already covers it)."""
        if self.session_factory is None:
            raise RuntimeError("TelegramService.session_factory is not set")
        async with self.session_factory() as session:
            session.add(NotificationLog(dedupe_key=dedupe_key[:250], chat_id="-", notification_status="sent"))
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()

    async def mark_sent_admins(self, dedupe_key: str) -> None:
        for c in self.chat_ids:
            await self.mark_sent(f"{dedupe_key}:{c}")
