"""Structured JSON logging with secret redaction."""
from __future__ import annotations

import json
import logging
import re
import sys
from datetime import datetime, timezone

_TOKEN_RE = re.compile(r"\b\d{6,}:[A-Za-z0-9_-]{20,}\b")  # Telegram bot token shape


def _redact(value):
    return _TOKEN_RE.sub("[REDACTED]", value) if isinstance(value, str) else value


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "severity": record.levelname,
            "logger": record.name,
            "message": _redact(record.getMessage()),
        }
        ctx = getattr(record, "ctx", None)
        if isinstance(ctx, dict):
            payload.update({k: _redact(v) for k, v in ctx.items()})
        return json.dumps(payload, default=str)


def configure_logging(level: str = "INFO") -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    handler._hv_handler = True  # type: ignore[attr-defined]
    root = logging.getLogger()
    # Replace only handlers installed by a previous call; leave foreign handlers untouched.
    root.handlers = [h for h in root.handlers if not getattr(h, "_hv_handler", False)] + [handler]
    root.setLevel(level)
    # httpx logs full request URLs at INFO, which would contain the Telegram bot token.
    for noisy in ("httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def log_event(logger: logging.Logger, level: int, event: str, **fields) -> None:
    """Log a structured event. Never pass secrets or raw payload values."""
    logger.log(level, event, extra={"ctx": fields})
