"""SQLAlchemy models. All timestamps are UTC."""
from __future__ import annotations

import enum
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, Numeric, String, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

PK_TYPE = BigInteger().with_variant(Integer, "sqlite")


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def as_utc(value: Optional[datetime]) -> Optional[datetime]:
    """Normalise datetimes (SQLite returns naive values) to aware UTC."""
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


class Base(DeclarativeBase):
    pass


class Event(Base):
    __tablename__ = "events"

    id: Mapped[int] = mapped_column(PK_TYPE, primary_key=True, autoincrement=True)
    external_event_id: Mapped[str] = mapped_column(String(128), nullable=False)
    event_name: Mapped[str] = mapped_column(String(64), nullable=False)
    click_id: Mapped[Optional[str]] = mapped_column(String(128))
    site_id: Mapped[Optional[str]] = mapped_column(String(128))
    link_id: Mapped[Optional[str]] = mapped_column(String(128))
    event_timestamp: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    source: Mapped[str] = mapped_column(String(16), nullable=False, default="api")
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utcnow)
    processed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    processing_status: Mapped[str] = mapped_column(String(16), nullable=False, default="received")
    failure_reason: Mapped[Optional[str]] = mapped_column(String(64))

    __table_args__ = (
        UniqueConstraint("external_event_id", name="uq_events_external_event_id"),
        Index("ix_events_event_name", "event_name"),
        Index("ix_events_received_at", "received_at"),
        Index("ix_events_processing_status", "processing_status"),
    )


class NotificationLog(Base):
    __tablename__ = "notification_logs"

    id: Mapped[int] = mapped_column(PK_TYPE, primary_key=True, autoincrement=True)
    dedupe_key: Mapped[str] = mapped_column(String(255), nullable=False)
    chat_id: Mapped[str] = mapped_column(String(64), nullable=False)
    notification_status: Mapped[str] = mapped_column(String(16), nullable=False, default="pending")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utcnow)

    __table_args__ = (
        UniqueConstraint("dedupe_key", name="uq_notification_logs_dedupe_key"),
        Index("ix_notification_logs_status", "notification_status"),
    )


# --------------------------------------------------------------------------
# Trader ID / deposit verification (ported from the old verification server).
# Table and column names are unchanged so existing databases stay compatible.
# --------------------------------------------------------------------------
class VerificationStatus(str, enum.Enum):
    VERIFIED = "verified"                    # linked + verified deposit >= minimum
    BELOW_MINIMUM = "below_minimum"          # linked, deposits found, total < minimum
    LINKED_NO_DEPOSIT = "linked_no_deposit"  # linked, no deposit yet
    UNLINKED = "unlinked"                    # account exists but is not under our affiliate account
    NOT_FOUND = "not_found"                  # Trader ID unknown to the affiliate API
    ALREADY_CLAIMED = "already_claimed"      # Trader ID already bound to another Telegram user
    CURRENCY_REVIEW = "currency_review"      # currency differs from DEPOSIT_CURRENCY; never converted
    ERROR = "error"                          # affiliate API call failed
    NOT_OPERATIONAL = "not_operational"      # affiliate integration not implemented/configured


class TraderRecord(Base):
    """A Trader ID the affiliate API confirmed is linked to us, bound to one Telegram user."""

    __tablename__ = "trader_records"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    trader_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    telegram_user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    telegram_username: Mapped[Optional[str]] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(32))
    linked: Mapped[bool] = mapped_column(Boolean, default=False)
    deposit_total: Mapped[Optional[Decimal]] = mapped_column(Numeric(18, 2))
    currency: Mapped[Optional[str]] = mapped_column(String(8))
    verified_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    last_checked_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class Deposit(Base):
    """A deposit exactly as reported by the official affiliate API."""

    __tablename__ = "deposits"
    __table_args__ = (UniqueConstraint("record_id", "provider_deposit_id", name="uq_deposit_per_record"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    record_id: Mapped[int] = mapped_column(ForeignKey("trader_records.id"), index=True)
    provider_deposit_id: Mapped[str] = mapped_column(String(128))
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2))
    currency: Mapped[str] = mapped_column(String(8))
    deposited_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class VerificationEvent(Base):
    """Append-only verification history (includes failures, which have no TraderRecord)."""

    __tablename__ = "verification_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    record_id: Mapped[Optional[int]] = mapped_column(ForeignKey("trader_records.id"), index=True)
    telegram_user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    trader_id: Mapped[str] = mapped_column(String(64), index=True)
    source: Mapped[str] = mapped_column(String(16))  # bot | webhook
    status: Mapped[str] = mapped_column(String(32))
    linked: Mapped[bool] = mapped_column(Boolean, default=False)
    deposit_total: Mapped[Optional[Decimal]] = mapped_column(Numeric(18, 2))
    currency: Mapped[Optional[str]] = mapped_column(String(8))
    detail: Mapped[Optional[str]] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
