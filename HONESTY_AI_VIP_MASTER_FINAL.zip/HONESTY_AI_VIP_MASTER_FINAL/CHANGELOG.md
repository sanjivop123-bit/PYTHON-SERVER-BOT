# Changelog

## 2.0.0 - Master merge (2026-11-13)
Base: HONESTY_AI_VIP_READY (new backend). Ported from the old verification server: everything listed in FEATURE_AUDIT.md.

### Added
- `app/verification_service.py`: Trader ID verification, deposit evaluation, ownership binding, provider contract (placeholder).
- Models `TraderRecord`, `Deposit`, `VerificationEvent` + Alembic `0002_verification` (idempotent for old databases).
- `POST /api/v1/verify`, `GET /api/v1/status/{trader_id}`, `POST /webhooks/affiliate/verify`, `/admin/api/users`, `/admin/api/history`.
- Dashboard sections: linked accounts, verification history, verified count, "not operational" banner.
- `TelegramService.send_text / send_once / send_once_admins / mark_sent(_admins)` (boolean send and cross-instance de-duplication).
- Settings: `MIN_DEPOSIT`, `DEPOSIT_CURRENCY`, `TRADER_ID_PATTERN`, `AFFILIATE_API_BASE_URL`, `AFFILIATE_API_KEY`, legacy `BOT_API_KEY`.
- `docker-compose.yml`, backup/recovery and old-DB upgrade notes, `tests/test_verification.py`.

### Changed (breaking, documented in DEPLOYMENT_GUIDE.md)
- Old `/webhooks/affiliate` re-verify trigger moved to `/webhooks/affiliate/verify` (path conflict with the event receiver).
- Old HTTP Basic admin -> session login with Argon2 hash (`ADMIN_PASSWORD_HASH`).
- Old `?token=` webhook secret removed; header/HMAC only. `ADMIN_CHAT_ID` -> `ADMIN_CHAT_IDS`. API keys must be >=32 chars.
- Old `notification_log` table superseded by `notification_logs` (rows copied by migration 0002; legacy table left in place).
- Old schema creation at startup (`create_all`) replaced by Alembic migrations.

### Removed (with reason)
- Old `main.py`, `config.py`, `database.py`, `models.py`, `telegram_service.py`, `Dockerfile`, `requirements.txt`: superseded by the new equivalents, functionality ported.
- Old single-file inline admin HTML: replaced by the Jinja2 (autoescaped) dashboard.

### Not changed
- No Telebot bot code existed in either ZIP; the bot is untouched.
