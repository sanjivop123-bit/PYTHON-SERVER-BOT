"""Generate an ADMIN_PASSWORD_HASH value: python scripts/hash_password.py"""
import getpass
import sys

from argon2 import PasswordHasher

password = getpass.getpass("Admin password (min 12 chars): ")
if len(password) < 12:
    sys.exit("Password too short.")
if password != getpass.getpass("Repeat: "):
    sys.exit("Passwords do not match.")
print(PasswordHasher().hash(password))
