# Security notes

## Implemented
- Secrets only from environment variables; `.env.example` has placeholders only.
- API keys (>=32 chars) compared in constant time; webhook secret/HMAC verified in constant time; secrets never accepted in URLs.
- Webhook disabled by default; unauthenticated requests are rejected before parsing.
- Strict input validation (character whitelist, length limits, unknown fields rejected); request body and query size limits.
- SQLAlchemy parametrised queries only; LIKE input escaped.
- Admin: Argon2 password hashing, signed `SameSite=Strict` session cookie (`Secure` in production), CSRF tokens, login rate limit, constant-work credential check.
- Jinja2 autoescaping, CSP, `X-Frame-Options`, `nosniff`, HSTS (production), `no-store` caching. No inline scripts.
- HTTPS-only in production (plain HTTP rejected except `/health`); API docs disabled in production.
- Error responses are generic; validation errors never echo submitted values. Logs are structured JSON, redact Telegram token shapes, and never log payload values; httpx request logging is suppressed because URLs contain the bot token.
- Process runs as a non-root user; graceful shutdown disposes DB pool and HTTP client.

## Verification-specific
- A Trader ID is bound to exactly one Telegram user (`already_claimed` otherwise); admins are alerted once per conflict.
- Provider failures are logged by exception type only and return a generic message; deposit currency mismatches go to
  `currency_review` instead of being converted. The old `?token=` webhook secret in URLs was removed.
- The old HTTP Basic admin with a plaintext `ADMIN_PASSWORD` was replaced by Argon2 + session + CSRF.

## Known limitations
- Rate limiting is in-memory and per instance; client IP comes from `X-Forwarded-For` (uvicorn trusts all proxies, which is correct only behind Cloud Run). Use Cloud Armor for stronger protection.
- Admin session is a signed (not encrypted) cookie holding only a flag and CSRF token; there is a single admin account.
- Failed Telegram notifications are recorded but not retried.
- Events that fail before the database insert cannot be recorded in the database; they are logged and the provider receives 503.
- Webhook authentication depends on provider capabilities that are **unverified** here.
- Dependencies are version-ranged, not pinned with hashes. Run `pip-audit` and pin before release.
- The test suite has not been executed in the build environment (no network/Docker available).
- Verification stores Trader IDs and Telegram IDs (personal data): restrict DB/admin access, define a retention policy and check local privacy rules.
