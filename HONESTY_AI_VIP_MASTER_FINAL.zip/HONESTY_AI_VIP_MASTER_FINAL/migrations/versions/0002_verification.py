"""verification tables (ported from the old server): trader_records, deposits, verification_events

Idempotent: databases created by the OLD server (via create_all) already contain these tables, so existing
tables are skipped. Rows of the old `notification_log` table are copied into `notification_logs` (status
'sent') so already-delivered notifications are not sent a second time; the legacy table is left in place.

Revision ID: 0002
Revises: 0001
"""
from alembic import op
import sqlalchemy as sa

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def _tables() -> set[str]:
    return set(sa.inspect(op.get_bind()).get_table_names())


def upgrade() -> None:
    existing = _tables()
    if "trader_records" not in existing:
        op.create_table(
            "trader_records",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("trader_id", sa.String(64), nullable=False),
            sa.Column("telegram_user_id", sa.BigInteger(), nullable=False),
            sa.Column("telegram_username", sa.String(64)),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column("linked", sa.Boolean(), nullable=False, server_default=sa.false()),
            sa.Column("deposit_total", sa.Numeric(18, 2)),
            sa.Column("currency", sa.String(8)),
            sa.Column("verified_at", sa.DateTime(timezone=True)),
            sa.Column("last_checked_at", sa.DateTime(timezone=True)),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        )
        op.create_index("ix_trader_records_trader_id", "trader_records", ["trader_id"], unique=True)
        op.create_index("ix_trader_records_telegram_user_id", "trader_records", ["telegram_user_id"])
    if "deposits" not in existing:
        op.create_table(
            "deposits",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("record_id", sa.Integer(), sa.ForeignKey("trader_records.id"), nullable=False),
            sa.Column("provider_deposit_id", sa.String(128), nullable=False),
            sa.Column("amount", sa.Numeric(18, 2), nullable=False),
            sa.Column("currency", sa.String(8), nullable=False),
            sa.Column("deposited_at", sa.DateTime(timezone=True)),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.UniqueConstraint("record_id", "provider_deposit_id", name="uq_deposit_per_record"),
        )
        op.create_index("ix_deposits_record_id", "deposits", ["record_id"])
    if "verification_events" not in existing:
        op.create_table(
            "verification_events",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("record_id", sa.Integer(), sa.ForeignKey("trader_records.id")),
            sa.Column("telegram_user_id", sa.BigInteger(), nullable=False),
            sa.Column("trader_id", sa.String(64), nullable=False),
            sa.Column("source", sa.String(16), nullable=False),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column("linked", sa.Boolean(), nullable=False, server_default=sa.false()),
            sa.Column("deposit_total", sa.Numeric(18, 2)),
            sa.Column("currency", sa.String(8)),
            sa.Column("detail", sa.String(255)),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        )
        op.create_index("ix_verification_events_record_id", "verification_events", ["record_id"])
        op.create_index("ix_verification_events_telegram_user_id", "verification_events", ["telegram_user_id"])
        op.create_index("ix_verification_events_trader_id", "verification_events", ["trader_id"])
        op.create_index("ix_verification_events_created_at", "verification_events", ["created_at"])
    if "notification_log" in existing:
        op.execute(
            "INSERT INTO notification_logs (dedupe_key, chat_id, notification_status, created_at) "
            "SELECT o.dedupe_key, o.chat_id, 'sent', o.created_at FROM notification_log o "
            "WHERE NOT EXISTS (SELECT 1 FROM notification_logs n WHERE n.dedupe_key = o.dedupe_key)"
        )


def downgrade() -> None:
    # Only drops what this revision may have created; the legacy notification_log table is untouched.
    for name, idx in (
        ("verification_events", ["ix_verification_events_created_at", "ix_verification_events_trader_id",
                                 "ix_verification_events_telegram_user_id", "ix_verification_events_record_id"]),
        ("deposits", ["ix_deposits_record_id"]),
        ("trader_records", ["ix_trader_records_telegram_user_id", "ix_trader_records_trader_id"]),
    ):
        for i in idx:
            op.drop_index(i, table_name=name)
        op.drop_table(name)
