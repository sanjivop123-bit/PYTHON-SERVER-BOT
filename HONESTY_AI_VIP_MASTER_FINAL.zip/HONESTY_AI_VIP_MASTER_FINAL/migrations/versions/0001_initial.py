"""initial schema: events and notification_logs

Revision ID: 0001
Revises:
Create Date: 2026-11-13
"""
from alembic import op
import sqlalchemy as sa

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "events",
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column("external_event_id", sa.String(128), nullable=False),
        sa.Column("event_name", sa.String(64), nullable=False),
        sa.Column("click_id", sa.String(128)),
        sa.Column("site_id", sa.String(128)),
        sa.Column("link_id", sa.String(128)),
        sa.Column("event_timestamp", sa.DateTime(timezone=True)),
        sa.Column("source", sa.String(16), nullable=False),
        sa.Column("received_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("processed_at", sa.DateTime(timezone=True)),
        sa.Column("processing_status", sa.String(16), nullable=False),
        sa.Column("failure_reason", sa.String(64)),
        sa.UniqueConstraint("external_event_id", name="uq_events_external_event_id"),
    )
    op.create_index("ix_events_event_name", "events", ["event_name"])
    op.create_index("ix_events_received_at", "events", ["received_at"])
    op.create_index("ix_events_processing_status", "events", ["processing_status"])

    op.create_table(
        "notification_logs",
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column("dedupe_key", sa.String(255), nullable=False),
        sa.Column("chat_id", sa.String(64), nullable=False),
        sa.Column("notification_status", sa.String(16), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("dedupe_key", name="uq_notification_logs_dedupe_key"),
    )
    op.create_index("ix_notification_logs_status", "notification_logs", ["notification_status"])


def downgrade() -> None:
    op.drop_index("ix_notification_logs_status", table_name="notification_logs")
    op.drop_table("notification_logs")
    op.drop_index("ix_events_processing_status", table_name="events")
    op.drop_index("ix_events_received_at", table_name="events")
    op.drop_index("ix_events_event_name", table_name="events")
    op.drop_table("events")
