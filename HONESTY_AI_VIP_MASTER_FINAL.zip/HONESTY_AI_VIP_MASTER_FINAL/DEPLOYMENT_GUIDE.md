# Deployment Guide - Google Cloud Run

Replace `PROJECT`, `REGION`, `SERVICE`, etc. Never put secrets in the repo or image.

## 1. PostgreSQL (Cloud SQL)
```
gcloud sql instances create honesty-pg --database-version=POSTGRES_16 --region=REGION --tier=db-custom-1-3840
gcloud sql databases create honesty --instance=honesty-pg
gcloud sql users create app_user --instance=honesty-pg --password="$(openssl rand -base64 24)"   # store it in Secret Manager
```
`DATABASE_URL` (Cloud SQL socket):
`postgresql+asyncpg://app_user:PASSWORD@/honesty?host=/cloudsql/PROJECT:REGION:honesty-pg`
(URL-encode special characters in the password.)

## 2. Secrets
```
python -c "import secrets;print(secrets.token_urlsafe(48))" | gcloud secrets create hv-secret-key --data-file=-
python -c "import secrets;print(secrets.token_urlsafe(48))" | gcloud secrets create hv-api-key --data-file=-
python scripts/hash_password.py | gcloud secrets create hv-admin-hash --data-file=-
printf '%s' "$DATABASE_URL" | gcloud secrets create hv-database-url --data-file=-
# optional: hv-telegram-token, hv-webhook-secret
```
Grant the Cloud Run service account `roles/secretmanager.secretAccessor` and `roles/cloudsql.client`.

## 3. Build and migrate
```
gcloud builds submit --tag REGION-docker.pkg.dev/PROJECT/REPO/honesty-ai-vip:v1
gcloud run jobs create hv-migrate --image REGION-docker.pkg.dev/PROJECT/REPO/honesty-ai-vip:v1 \
  --region REGION --set-cloudsql-instances PROJECT:REGION:honesty-pg \
  --set-secrets DATABASE_URL=hv-database-url:latest --command alembic --args upgrade,head
gcloud run jobs execute hv-migrate --region REGION --wait
```

## 4. Deploy
```
gcloud run deploy SERVICE --image REGION-docker.pkg.dev/PROJECT/REPO/honesty-ai-vip:v1 --region REGION \
  --allow-unauthenticated --min-instances 1 --max-instances 5 --cpu 1 --memory 512Mi \
  --add-cloudsql-instances PROJECT:REGION:honesty-pg \
  --set-env-vars ENVIRONMENT=production,ADMIN_USERNAME=admin,WEBHOOK_AUTH_MODE=disabled \
  --set-secrets DATABASE_URL=hv-database-url:latest,SECRET_KEY=hv-secret-key:latest,API_KEYS=hv-api-key:latest,ADMIN_PASSWORD_HASH=hv-admin-hash:latest
```
Public ingress is required for the provider/Telegram callbacks; access to data is protected by API key,
webhook authentication and admin login. Cloud Run serves HTTPS only. Keep `WEBHOOK_AUTH_MODE=disabled`
until a supported authentication mechanism is confirmed, then set `header` or `hmac` plus `WEBHOOK_SECRET`.

## Environment variables
See `.env.example` for the full list. Required in production: `ENVIRONMENT`, `DATABASE_URL`,
`SECRET_KEY`, `API_KEYS`, `ADMIN_USERNAME`, `ADMIN_PASSWORD_HASH`. The app refuses to start with an
invalid production configuration.

## Health checks
Startup/liveness probe: `GET /health`. Readiness/diagnostics: `GET /api/v1/health` (503 if DB unreachable).

## Multiple instances
Events and notification dedupe are enforced by PostgreSQL unique constraints, so concurrent instances are safe.
Rate limiting is in-memory per instance (see SECURITY.md).

## Rollback
```
gcloud run revisions list --service SERVICE --region REGION
gcloud run services update-traffic SERVICE --region REGION --to-revisions REVISION=100
```
Migrations: `alembic downgrade -1` (run as a job with `--args downgrade,-1`). Back up before schema changes.

## Upgrading an existing OLD verification-server database
The old server created its tables with `create_all` (no Alembic). Migration `0002` is idempotent:
1. Back up first (see Backup below).
2. The old DB has no `alembic_version` table, so run `alembic upgrade head` as usual: `0001` creates the
   new `events` and `notification_logs` tables (absent in the old DB), and `0002` skips tables that already
   exist and copies old `notification_log` rows into `notification_logs` so past notifications are not re-sent.
3. Update the environment (below) and deploy the new image.
**This upgrade path has NOT been executed** (see TEST_REPORT.md). Rehearse it on a copy of the database.

### Environment changes vs the old server
| Old | New |
|---|---|
| `BOT_API_KEY` (>=24 chars) | still accepted (added to `API_KEYS`) but must now be >=32 chars; prefer `API_KEYS` |
| `ADMIN_PASSWORD` (HTTP Basic) | `ADMIN_PASSWORD_HASH` (Argon2, `python scripts/hash_password.py`); login form + session at `/admin/login` |
| `AFFILIATE_WEBHOOK_SECRET` + `?token=` | `WEBHOOK_AUTH_MODE=header|hmac` + `WEBHOOK_SECRET`; secrets in URLs are no longer accepted |
| `/webhooks/affiliate` (re-verify trigger) | moved to `POST /webhooks/affiliate/verify`; `/webhooks/affiliate` is now the event-tracking receiver |
| `MIN_DEPOSIT` (required) | `MIN_DEPOSIT` (optional; unset => verification reports `not_operational`) |
| `ADMIN_CHAT_ID` | `ADMIN_CHAT_IDS` (comma-separated) |
| `TELEGRAM_BOT_TOKEN`, `DEPOSIT_CURRENCY`, `TRADER_ID_PATTERN`, `AFFILIATE_API_*`, `DATABASE_URL`, `ENVIRONMENT`, `LOG_LEVEL` | unchanged |
Update your Telebot bot's calls only if it uses the old webhook path or sends a key shorter than 32 chars;
`POST /api/v1/verify` and `GET /api/v1/status/{trader_id}` are unchanged (header `X-API-Key`).

## Local run with Docker Compose
`docker compose up --build` (see variables at the top of `docker-compose.yml`). Development mode only.
**Not executed in the build environment.**

## Backup and recovery
- Cloud SQL automated backups + point-in-time recovery: `gcloud sql instances patch honesty-pg --backup-start-time=03:00 --enable-point-in-time-recovery`
- On-demand: `gcloud sql backups create --instance honesty-pg`
- Logical dump: `gcloud sql export sql honesty-pg gs://BUCKET/honesty-$(date +%F).sql --database=honesty`
- Restore: `gcloud sql backups restore BACKUP_ID --restore-instance=honesty-pg` (or import the SQL dump into a new instance).
- Back up before every migration. Test a restore periodically; an untested backup is not a backup.
