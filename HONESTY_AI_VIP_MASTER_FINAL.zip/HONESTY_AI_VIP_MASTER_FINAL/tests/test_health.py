from sqlalchemy.exc import OperationalError


def test_app_starts_and_health_ok(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


def test_api_health_reports_database_up(client):
    r = client.get("/api/v1/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok", "database": "up"}


def test_api_health_reports_database_down(client, monkeypatch):
    async def down():
        return False

    monkeypatch.setattr(client.fastapi_app.state.db, "ping", down)
    r = client.get("/api/v1/health")
    assert r.status_code == 503
    assert r.json()["database"] == "down"


def test_security_headers_present(client):
    r = client.get("/health")
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"
    assert "frame-ancestors 'none'" in r.headers["content-security-policy"]


def test_unknown_route_404(client):
    assert client.get("/nope").status_code == 404
