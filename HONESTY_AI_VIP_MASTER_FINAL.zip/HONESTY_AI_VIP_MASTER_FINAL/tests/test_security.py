import re

import pytest

from app.config import ConfigError, Settings
from app.security import RateLimiter, hash_password, verify_api_key, verify_password
from tests.conftest import ADMIN_PASSWORD, API_KEY, HEADERS, WEBHOOK_SECRET, make_settings

CSRF_RE = re.compile(r'name="csrf_token" value="([^"]+)"')


def _csrf(client, path="/admin/login"):
    return CSRF_RE.search(client.get(path).text).group(1)


def _login(client, password=ADMIN_PASSWORD, username="admin"):
    return client.post(
        "/admin/login",
        data={"username": username, "password": password, "csrf_token": _csrf(client)},
        follow_redirects=False,
    )


# ---- primitives
def test_password_hashing():
    h = hash_password("a-long-password-1")
    assert h != "a-long-password-1" and h.startswith("$argon2")
    assert verify_password(h, "a-long-password-1")
    assert not verify_password(h, "wrong")
    assert not verify_password("garbage", "x")
    assert not verify_password(h, "x" * 1000)


def test_api_key_verification():
    assert verify_api_key(API_KEY, (API_KEY,))
    assert not verify_api_key("other", (API_KEY,))
    assert not verify_api_key(None, (API_KEY,))
    assert not verify_api_key("", ())


def test_rate_limiter_window():
    rl = RateLimiter()
    assert [rl.allow("k", 2, 60, now=0) for _ in range(3)] == [True, True, False]
    assert rl.allow("k", 2, 60, now=61)
    assert rl.allow("other", 2, 60, now=0)


# ---- admin
def test_admin_requires_login(client):
    r = client.get("/admin", follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/admin/login"


def test_admin_login_success_and_dashboard(client):
    client.post("/api/v1/events", json={"event_id": "<script>1", "event_name": "x"}, headers=HEADERS)
    client.post("/api/v1/events", json={"event_id": "OK1", "event_name": "registration"}, headers=HEADERS)
    r = _login(client)
    assert r.status_code == 303
    page = client.get("/admin")
    assert page.status_code == 200
    assert "Total events" in page.text and "OK1" in page.text
    assert "Database" in page.text
    filtered = client.get("/admin", params={"q": "OK", "event_name": "registration"})
    assert "OK1" in filtered.text


def test_admin_output_is_html_escaped(client):
    # A value that passes validation can't contain markup; verify escaping of reflected filters instead.
    _login(client)
    page = client.get("/admin", params={"q": '"><script>alert(1)</script>'})
    assert "<script>alert(1)</script>" not in page.text


def test_admin_login_failures(client):
    assert _login(client, password="wrong").status_code == 401
    assert _login(client, username="root").status_code == 401
    assert client.get("/admin", follow_redirects=False).status_code == 303


def test_admin_login_requires_csrf(client):
    r = client.post("/admin/login", data={"username": "admin", "password": ADMIN_PASSWORD, "csrf_token": "bad"})
    assert r.status_code == 403


def test_admin_login_rate_limited(client):
    codes = [_login(client, password="wrong").status_code for _ in range(7)]
    assert codes[:5] == [401] * 5
    assert codes[5:] == [429, 429]


def test_admin_logout(client):
    _login(client)
    token = _csrf(client, "/admin")
    r = client.post("/admin/logout", data={"csrf_token": token}, follow_redirects=False)
    assert r.status_code == 303
    assert client.get("/admin", follow_redirects=False).status_code == 303


def test_admin_not_configured(make_client):
    c = make_client(admin_username="", admin_password_hash="")
    r = c.post("/admin/login", data={"username": "a", "password": "b", "csrf_token": _csrf(c)})
    assert r.status_code == 503


# ---- API rate limiting
def test_api_rate_limiting(make_client):
    c = make_client(rate_limit_per_minute=3)
    codes = [c.get("/api/v1/events", headers=HEADERS).status_code for _ in range(5)]
    assert codes == [200, 200, 200, 429, 429]


# ---- logging hygiene
def test_secrets_not_logged(make_client, caplog):
    caplog.set_level("DEBUG")
    c = make_client()
    c.get("/webhooks/affiliate", params={"event_id": "E1", "status": "x"}, headers={"X-Webhook-Secret": "bad" * 15})
    c.post("/api/v1/events", json={"event_id": "E2", "event_name": "x"}, headers=HEADERS)
    for secret in (API_KEY, WEBHOOK_SECRET):
        assert secret not in caplog.text


# ---- production configuration
PROD_ENV = {
    "ENVIRONMENT": "production",
    "DATABASE_URL": "postgresql+asyncpg://u:p@/db?host=/cloudsql/x:y:z",
    "SECRET_KEY": "s" * 48,
    "API_KEYS": API_KEY,
    "ADMIN_USERNAME": "admin",
    "ADMIN_PASSWORD_HASH": "$argon2id$placeholder",
}


def test_production_config_valid():
    s = Settings.from_env(PROD_ENV)
    assert s.is_production and s.webhook_auth_mode == "disabled"


@pytest.mark.parametrize(
    "key,value",
    [
        ("SECRET_KEY", "short"),
        ("SECRET_KEY", ""),
        ("API_KEYS", "tooshort"),
        ("API_KEYS", ""),
        ("DATABASE_URL", "sqlite+aiosqlite:///x.db"),
        ("ADMIN_PASSWORD_HASH", ""),
        ("WEBHOOK_AUTH_MODE", "header"),  # enabled without WEBHOOK_SECRET
        ("WEBHOOK_AUTH_MODE", "bogus"),
        ("TELEGRAM_BOT_TOKEN", "123456:abc"),  # without ADMIN_CHAT_IDS
        ("WEBHOOK_FIELD_MAP", '{"event_id":"event_id","event_name":"status","click_id":"trader_id"}'),
        ("WEBHOOK_FIELD_MAP", '{"event_id":"event_id","event_name":"status","deposit":"sumdep"}'),
        ("WEBHOOK_FIELD_MAP", "not json"),
    ],
)
def test_production_config_rejects_unsafe(key, value):
    with pytest.raises(ConfigError) as exc:
        Settings.from_env({**PROD_ENV, key: value})
    assert str(exc.value)


def test_config_errors_do_not_leak_secret_values():
    with pytest.raises(ConfigError) as exc:
        Settings.from_env({**PROD_ENV, "API_KEYS": "leaky-short-key"})
    assert "leaky-short-key" not in str(exc.value)


def test_production_enforces_https(make_client, admin_hash):
    from fastapi.testclient import TestClient

    from app.main import create_app

    settings = make_settings(
        admin_hash, environment="production", database_url="postgresql+asyncpg://u:p@localhost/db"
    )
    app = create_app(settings=settings)
    with TestClient(app, base_url="http://testserver") as http_client:
        assert http_client.get("/api/v1/events", headers=HEADERS).status_code == 400
        assert http_client.get("/health").status_code == 200  # liveness probe is exempt
        assert http_client.get("/docs").status_code in (400, 404)
    with TestClient(app, base_url="https://testserver") as https_client:
        assert https_client.get("/docs").status_code == 404  # docs disabled in production
        assert "strict-transport-security" in https_client.get("/health").headers
