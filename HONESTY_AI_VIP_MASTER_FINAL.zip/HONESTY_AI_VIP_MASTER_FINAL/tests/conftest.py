import httpx
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.config import Settings
from app.main import create_app
from app.models import NotificationLog
from app.security import hash_password
from app.telegram_service import TelegramService

API_KEY = "test-api-key-" + "k" * 32
WEBHOOK_SECRET = "w" * 40
BOT_TOKEN = "123456789:AAFAKETOKENFORTESTSONLY_abcdefghijk"
ADMIN_PASSWORD = "correct horse battery staple"
HEADERS = {"X-API-Key": API_KEY}
WH_HEADERS = {"X-Webhook-Secret": WEBHOOK_SECRET}


@pytest.fixture(scope="session")
def admin_hash():
    return hash_password(ADMIN_PASSWORD)


def make_settings(admin_hash, **overrides) -> Settings:
    base = dict(
        environment="test",
        database_url="sqlite+aiosqlite:///:memory:",
        secret_key="s" * 48,
        api_keys=(API_KEY,),
        admin_username="admin",
        admin_password_hash=admin_hash,
        webhook_auth_mode="header",
        webhook_secret=WEBHOOK_SECRET,
        telegram_bot_token=BOT_TOKEN,
        admin_chat_ids=("1001",),
        rate_limit_per_minute=1000,
        login_rate_limit_per_minute=5,
    )
    base.update(overrides)
    settings = Settings(**base)
    settings.validate()
    return settings


def make_telegram(settings, handler=None):
    calls = []

    def default_handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"ok": True, "result": {}})

    def recording(request: httpx.Request) -> httpx.Response:
        calls.append(request)
        return (handler or default_handler)(request)

    service = TelegramService(
        settings.telegram_bot_token, settings.admin_chat_ids, transport=httpx.MockTransport(recording)
    )
    return service, calls


async def fetch_notification_logs(app):
    async with app.state.db.session_factory() as s:
        return list((await s.execute(select(NotificationLog))).scalars().all())


@pytest.fixture
def make_client(admin_hash):
    entered = []

    def _make(telegram_handler=None, **overrides):
        settings = make_settings(admin_hash, **overrides)
        telegram, calls = make_telegram(settings, telegram_handler)
        app = create_app(settings=settings, telegram=telegram)
        cm = TestClient(app, base_url="https://testserver")
        client = cm.__enter__()
        client.portal.call(app.state.db.create_all)
        entered.append(cm)
        client.tg_calls = calls
        client.fastapi_app = app
        return client

    yield _make
    for cm in entered:
        cm.__exit__(None, None, None)


@pytest.fixture
def client(make_client):
    return make_client()
