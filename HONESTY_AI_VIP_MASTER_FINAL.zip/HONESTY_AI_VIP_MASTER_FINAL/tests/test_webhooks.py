import hashlib
import hmac

from tests.conftest import HEADERS, WH_HEADERS, WEBHOOK_SECRET

URL = "/webhooks/affiliate"
PARAMS = {"status": "registration", "event_id": "EV1", "click_id": "CK1", "site_id": "S1", "lid": "L1"}


def test_get_webhook_parsed(client):
    r = client.get(URL, params=PARAMS, headers=WH_HEADERS)
    assert r.status_code == 200
    assert r.json() == {"status": "accepted", "duplicate": False, "event_id": "EV1"}
    stored = client.get("/api/v1/events/EV1", headers=HEADERS).json()
    assert stored["event_name"] == "registration"
    assert stored["link_id"] == "L1"
    assert stored["source"] == "webhook"


def test_post_json_parsed(client):
    r = client.post(URL, json=PARAMS, headers=WH_HEADERS)
    assert r.status_code == 200
    assert client.get("/api/v1/events/EV1", headers=HEADERS).json()["click_id"] == "CK1"


def test_post_form_parsed(client):
    r = client.post(URL, data=PARAMS, headers=WH_HEADERS)
    assert r.status_code == 200
    assert client.get("/api/v1/events/EV1", headers=HEADERS).json()["site_id"] == "S1"


def test_unauthenticated_webhook_rejected(client):
    assert client.get(URL, params=PARAMS).status_code == 401
    assert client.get(URL, params=PARAMS, headers={"X-Webhook-Secret": "wrong" * 10}).status_code == 401
    assert client.get("/api/v1/events", headers=HEADERS).json()["total"] == 0


def test_secret_in_url_is_not_accepted(client):
    assert client.get(URL, params={**PARAMS, "secret": WEBHOOK_SECRET}).status_code == 401


def test_webhook_disabled_by_default_refuses_processing(make_client):
    c = make_client(webhook_auth_mode="disabled", webhook_secret="")
    r = c.get(URL, params=PARAMS, headers=WH_HEADERS)
    assert r.status_code == 503
    assert c.get("/api/v1/events", headers=HEADERS).json()["total"] == 0


def test_hmac_mode(make_client):
    c = make_client(webhook_auth_mode="hmac")
    body = b'{"event_id":"H1","status":"registration"}'
    sig = hmac.new(WEBHOOK_SECRET.encode(), body, hashlib.sha256).hexdigest()
    ok = c.post(URL, content=body, headers={"content-type": "application/json", "X-Webhook-Signature": sig})
    assert ok.status_code == 200
    bad = c.post(URL, content=body, headers={"content-type": "application/json", "X-Webhook-Signature": "0" * 64})
    assert bad.status_code == 401
    qs = b"event_id=H2&status=registration"
    sig_get = hmac.new(WEBHOOK_SECRET.encode(), qs, hashlib.sha256).hexdigest()
    assert c.get(URL + "?" + qs.decode(), headers={"X-Webhook-Signature": sig_get}).status_code == 200


def test_invalid_webhook_payloads(client):
    assert client.get(URL, params={"status": "registration"}, headers=WH_HEADERS).status_code == 422
    assert client.get(URL, params={"event_id": "{event_id}", "status": "x"}, headers=WH_HEADERS).status_code == 422
    assert client.post(URL, content=b"[]", headers={**WH_HEADERS, "content-type": "application/json"}).status_code == 400
    assert client.post(URL, content=b"{bad", headers={**WH_HEADERS, "content-type": "application/json"}).status_code == 400
    assert client.post(URL, content=b"hi", headers={**WH_HEADERS, "content-type": "text/plain"}).status_code == 415
    nested = b'{"event_id":"E","status":{"a":1}}'
    assert client.post(URL, content=nested, headers={**WH_HEADERS, "content-type": "application/json"}).status_code == 400


def test_sensitive_fields_are_discarded(client):
    params = {**PARAMS, "trader_id": "TRADER-777", "sumdep": "123.45", "sumwithdraw": "9", "country": "XX", "useragent": "UA-SECRET"}
    assert client.get(URL, params=params, headers=WH_HEADERS).status_code == 200
    stored = client.get("/api/v1/events/EV1", headers=HEADERS).text
    for secret in ("TRADER-777", "123.45", "UA-SECRET"):
        assert secret not in stored
        assert all(secret not in c.content.decode() for c in client.tg_calls)


def test_duplicate_webhook_is_idempotent(client):
    assert client.get(URL, params=PARAMS, headers=WH_HEADERS).json()["duplicate"] is False
    second = client.post(URL, data=PARAMS, headers=WH_HEADERS)
    assert second.status_code == 200 and second.json()["duplicate"] is True
    assert client.get("/api/v1/events", headers=HEADERS).json()["total"] == 1
    assert len(client.tg_calls) == 1


def test_method_restriction(make_client):
    c = make_client(webhook_methods=("POST",))
    assert c.get(URL, params=PARAMS, headers=WH_HEADERS).status_code == 405
    assert c.post(URL, data=PARAMS, headers=WH_HEADERS).status_code == 200


def test_custom_field_map(make_client):
    c = make_client(webhook_field_map={"event_id": "eid", "event_name": "type"})
    assert c.get(URL, params={"eid": "M1", "type": "signup"}, headers=WH_HEADERS).status_code == 200
    assert c.get("/api/v1/events/M1", headers=HEADERS).json()["event_name"] == "signup"


def test_oversized_webhook_body_rejected(make_client):
    c = make_client(max_request_bytes=100)
    r = c.post(URL, data={**PARAMS, "pad": "x" * 500}, headers=WH_HEADERS)
    assert r.status_code == 413


def test_webhook_rate_limited(make_client):
    c = make_client(rate_limit_per_minute=2)
    codes = [c.get(URL, params={**PARAMS, "event_id": f"R{i}"}, headers=WH_HEADERS).status_code for i in range(4)]
    assert codes[:2] == [200, 200] and codes[2:] == [429, 429]
