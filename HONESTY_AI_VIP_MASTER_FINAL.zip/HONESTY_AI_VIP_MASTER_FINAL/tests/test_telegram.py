import asyncio

import httpx
import pytest

from app.database import Database
from app.models import utcnow
from app.telegram_service import TelegramError, TelegramService
from tests.conftest import BOT_TOKEN, HEADERS, fetch_notification_logs, make_settings

EVENT = {"event_id": "EVT1", "event_name": "registration"}


def test_notification_sent_with_expected_format(client):
    client.post("/api/v1/events", json=EVENT, headers=HEADERS)
    assert len(client.tg_calls) == 1
    req = client.tg_calls[0]
    assert req.url.path == f"/bot{BOT_TOKEN}/sendMessage"
    text = __import__("json").loads(req.content)["text"]
    assert text.startswith("HONESTY AI VIP SERVER")
    assert "Event Received: Registration" in text
    assert "Event ID: EVT1" in text
    assert "Processing: Successful" in text
    assert text.rstrip().endswith("UTC")
    logs = client.portal.call(fetch_notification_logs, client.fastapi_app)
    assert [(l.chat_id, l.notification_status) for l in logs] == [("1001", "sent")]


def test_only_send_message_endpoint_is_used(client):
    client.post("/api/v1/events", json=EVENT, headers=HEADERS)
    for req in client.tg_calls:
        assert req.url.path.endswith("/sendMessage")
        assert "getUpdates" not in str(req.url) and "Webhook" not in str(req.url)


def test_telegram_http_error_does_not_fail_event(make_client):
    c = make_client(telegram_handler=lambda r: httpx.Response(500, json={"ok": False}))
    r = c.post("/api/v1/events", json=EVENT, headers=HEADERS)
    assert r.status_code == 201
    assert r.json()["notification"] == "failed"
    assert c.get("/api/v1/events/EVT1", headers=HEADERS).json()["processing_status"] == "processed"
    logs = c.portal.call(fetch_notification_logs, c.fastapi_app)
    assert logs[0].notification_status == "failed"


def test_telegram_rate_limited_and_network_errors(make_client):
    c = make_client(telegram_handler=lambda r: httpx.Response(429, json={"ok": False}))
    assert c.post("/api/v1/events", json=EVENT, headers=HEADERS).json()["notification"] == "failed"

    def network_down(request):
        raise httpx.ConnectError("boom connecting to " + str(request.url))

    c2 = make_client(telegram_handler=network_down)
    r = c2.post("/api/v1/events", json=EVENT, headers=HEADERS)
    assert r.status_code == 201 and r.json()["notification"] == "failed"


def test_token_never_logged_or_returned(make_client, caplog):
    def network_down(request):
        raise httpx.ConnectError("failed " + str(request.url))

    caplog.set_level("DEBUG")
    c = make_client(telegram_handler=network_down)
    r = c.post("/api/v1/events", json=EVENT, headers=HEADERS)
    assert BOT_TOKEN not in r.text
    assert BOT_TOKEN not in caplog.text
    assert BOT_TOKEN not in repr(c.fastapi_app.state.telegram)


def test_not_configured_is_reported(make_client):
    c = make_client(telegram_bot_token="", admin_chat_ids=())
    r = c.post("/api/v1/events", json=EVENT, headers=HEADERS)
    assert r.status_code == 201
    assert r.json()["notification"] == "not_configured"
    assert c.tg_calls == []


def test_notification_dedupe_across_calls(admin_hash):
    async def run():
        settings = make_settings(admin_hash)
        db = Database(settings)
        await db.create_all()
        sent = []

        def handler(request):
            sent.append(request)
            return httpx.Response(200, json={"ok": True})

        tg = TelegramService(BOT_TOKEN, ("1001", "1002"), transport=httpx.MockTransport(handler))
        async with db.session_factory() as s:
            first = await tg.notify_event(s, "D1", "registration", utcnow())
        async with db.session_factory() as s:
            second = await tg.notify_event(s, "D1", "registration", utcnow())
        await tg.aclose()
        await db.dispose()
        return first, second, len(sent)

    first, second, n = asyncio.run(run())
    assert (first, second, n) == ("sent", "duplicate", 2)


def test_send_message_raises_only_reason_codes():
    async def run():
        tg = TelegramService(
            BOT_TOKEN, ("1",), transport=httpx.MockTransport(lambda r: httpx.Response(401, json={"ok": False}))
        )
        try:
            await tg.send_message("1", "hi")
        finally:
            await tg.aclose()

    with pytest.raises(TelegramError) as exc:
        asyncio.run(run())
    assert str(exc.value) == "http_401"
    assert BOT_TOKEN not in str(exc.value)
