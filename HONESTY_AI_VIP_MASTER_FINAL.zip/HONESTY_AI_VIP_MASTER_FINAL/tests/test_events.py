from sqlalchemy.exc import OperationalError

from app import event_service
from tests.conftest import HEADERS

EVENT = {"event_id": "EVENT123", "event_name": "Registration", "click_id": "c1", "site_id": "s1", "link_id": "l1"}


def test_requires_api_key(client):
    assert client.post("/api/v1/events", json=EVENT).status_code == 401
    assert client.get("/api/v1/events").status_code == 401
    assert client.get("/api/v1/events/EVENT123").status_code == 401


def test_wrong_api_key_rejected(client):
    r = client.post("/api/v1/events", json=EVENT, headers={"X-API-Key": "x" * 40})
    assert r.status_code == 401


def test_create_and_fetch_event(client):
    r = client.post("/api/v1/events", json=EVENT, headers=HEADERS)
    assert r.status_code == 201
    body = r.json()
    assert body["duplicate"] is False
    assert body["event"]["processing_status"] == "processed"
    assert body["event"]["event_name"] == "registration"
    got = client.get("/api/v1/events/EVENT123", headers=HEADERS)
    assert got.status_code == 200
    assert got.json()["click_id"] == "c1"


def test_missing_event_404(client):
    assert client.get("/api/v1/events/NOPE", headers=HEADERS).status_code == 404


def test_duplicate_event_not_reprocessed(client):
    assert client.post("/api/v1/events", json=EVENT, headers=HEADERS).status_code == 201
    r = client.post("/api/v1/events", json=EVENT, headers=HEADERS)
    assert r.status_code == 200
    assert r.json()["duplicate"] is True
    listing = client.get("/api/v1/events", headers=HEADERS).json()
    assert listing["total"] == 1
    assert len(client.tg_calls) == 1  # notified once only


def test_invalid_payloads_rejected(client):
    bad = [
        {"event_name": "x"},  # missing id
        {"event_id": "a b", "event_name": "x"},  # space
        {"event_id": "{event_id}", "event_name": "x"},  # unresolved macro
        {"event_id": "E1", "event_name": "x", "trader_id": "99"},  # undocumented/sensitive field
        {"event_id": "E1", "event_name": "x", "event_timestamp": "not-a-date"},
        {"event_id": "E" * 200, "event_name": "x"},
    ]
    for payload in bad:
        r = client.post("/api/v1/events", json=payload, headers=HEADERS)
        assert r.status_code == 422, payload
        assert "99" not in r.text  # submitted values are not echoed


def test_malformed_json_rejected(client):
    r = client.post("/api/v1/events", content=b"{oops", headers={**HEADERS, "content-type": "application/json"})
    assert r.status_code == 422


def test_listing_filters_and_search(client):
    for i, name in enumerate(["registration", "registration", "ftd"]):
        client.post("/api/v1/events", json={"event_id": f"AB{i}", "event_name": name}, headers=HEADERS)
    client.post("/api/v1/events", json={"event_id": "ZZ9", "event_name": "ftd"}, headers=HEADERS)
    by_name = client.get("/api/v1/events", params={"event_name": "ftd"}, headers=HEADERS).json()
    assert by_name["total"] == 2
    by_id = client.get("/api/v1/events", params={"q": "AB"}, headers=HEADERS).json()
    assert by_id["total"] == 3
    by_date = client.get("/api/v1/events", params={"date_from": "2999-01-01"}, headers=HEADERS).json()
    assert by_date["total"] == 0
    assert client.get("/api/v1/events", params={"limit": 1000}, headers=HEADERS).status_code == 422


def test_sql_injection_attempt_is_rejected_by_validation(client):
    r = client.get("/api/v1/events", params={"q": "' OR 1=1 --"}, headers=HEADERS)
    assert r.status_code == 422


def test_database_failure_returns_503_without_details(client, monkeypatch):
    async def boom(*a, **k):
        raise OperationalError("SELECT secret_table", {}, Exception("password=hunter2"))

    monkeypatch.setattr(event_service, "process_event", boom)
    r = client.post("/api/v1/events", json=EVENT, headers=HEADERS)
    assert r.status_code == 503
    assert "hunter2" not in r.text and "secret_table" not in r.text


def test_oversized_body_rejected(make_client):
    c = make_client(max_request_bytes=200)
    r = c.post("/api/v1/events", content=b"x" * 500, headers={**HEADERS, "content-type": "application/json"})
    assert r.status_code == 413
