"""Tests for the Trader ID / deposit verification features ported from the old server.

FakeProvider is a TEST DOUBLE only (it lives in tests/, never in app/). Production code ships with the
non-operational placeholder until the official affiliate API is implemented.
"""
import json
import re
from decimal import Decimal

import pytest

from app.config import ConfigError, Settings
from app.models import VerificationStatus as S
from app.verification_service import (
    InvalidTraderId, ProviderDeposit, TraderLookup, evaluate, normalize_trader_id,
)
from tests.conftest import ADMIN_PASSWORD, HEADERS, WH_HEADERS, make_settings

CSRF_RE = re.compile(r'name="csrf_token" value="([^"]+)"')
MIN = Decimal("50")


class FakeProvider:
    operational = True

    def __init__(self, lookup: TraderLookup):
        self.lookup = lookup
        self.calls = 0

    async def lookup_trader(self, trader_id: str) -> TraderLookup:
        self.calls += 1
        return self.lookup


def dep(i, amount, cur="USD"):
    return ProviderDeposit(provider_deposit_id=i, amount=Decimal(amount), currency=cur)


def body(**kw):
    return {"telegram_user_id": 111, "trader_id": "TRADER123", **kw}


@pytest.fixture
def vclient(make_client):
    def _make(lookup=None, **overrides):
        c = make_client(min_deposit=MIN, **overrides)
        if lookup is not None:
            c.fastapi_app.state.provider = FakeProvider(lookup)
        return c

    return _make


# ---------------------------------------------------------------- pure logic
def test_evaluate_rules():
    assert evaluate(TraderLookup(False, False), MIN, "USD") == (S.NOT_FOUND, None)
    assert evaluate(TraderLookup(True, False), MIN, "USD") == (S.UNLINKED, None)
    assert evaluate(TraderLookup(True, True), MIN, "USD") == (S.LINKED_NO_DEPOSIT, Decimal("0.00"))
    assert evaluate(TraderLookup(True, True, [dep("a", "20")]), MIN, "USD") == (S.BELOW_MINIMUM, Decimal("20.00"))
    assert evaluate(TraderLookup(True, True, [dep("a", "20"), dep("b", "30")]), MIN, "USD") == (S.VERIFIED, Decimal("50.00"))
    assert evaluate(TraderLookup(True, True, [dep("a", "99", "EUR")]), MIN, "USD") == (S.CURRENCY_REVIEW, None)


def test_trader_id_validation():
    s = Settings()
    assert normalize_trader_id(" ABC-123 ", s) == "ABC-123"
    for bad in ("", "ab", "x" * 33, "a b c", "a;drop", "../x"):
        with pytest.raises(InvalidTraderId):
            normalize_trader_id(bad, s)


# ---------------------------------------------------------------- config
def test_min_deposit_must_be_positive():
    with pytest.raises(ConfigError):
        Settings(secret_key="s" * 48, min_deposit=Decimal("0")).validate()


def test_legacy_bot_api_key_is_accepted_from_env():
    key = "legacy-" + "k" * 30
    s = Settings.from_env({"SECRET_KEY": "s" * 48, "BOT_API_KEY": key, "MIN_DEPOSIT": "25"})
    assert key in s.api_keys and s.min_deposit == Decimal("25") and s.verification_configured


# ---------------------------------------------------------------- not operational (default build)
def test_health_reports_verification_not_operational(client):
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["verification_operational"] is False


def test_verify_returns_503_not_operational_and_fabricates_nothing(vclient):
    c = vclient()
    r = c.post("/api/v1/verify", json=body(), headers=HEADERS)
    j = r.json()
    assert r.status_code == 503 and j["status"] == "not_operational"
    assert j["verified"] is False and j["verified_deposit_total"] is None
    assert c.get("/api/v1/status/TRADER123", headers=HEADERS).status_code == 404


def test_verify_requires_api_key_and_valid_id(vclient):
    c = vclient()
    assert c.post("/api/v1/verify", json=body()).status_code == 401
    assert c.post("/api/v1/verify", json=body(), headers={"X-API-Key": "wrong"}).status_code == 401
    c2 = vclient(TraderLookup(True, True))
    assert c2.post("/api/v1/verify", json=body(trader_id="a b"), headers=HEADERS).status_code == 422
    assert c2.post("/api/v1/verify", json={"trader_id": "TRADER123"}, headers=HEADERS).status_code == 422


# ---------------------------------------------------------------- verification flow (test double)
def test_verified_flow_persists_and_notifies_once(vclient):
    c = vclient(TraderLookup(True, True, [dep("d1", "60")]))
    r = c.post("/api/v1/verify", json=body(telegram_username="bob"), headers=HEADERS)
    j = r.json()
    assert r.status_code == 200 and j["verified"] is True and j["verified_deposit_total"] == "60.00"
    sent_first = len(c.tg_calls)
    assert sent_first >= 2  # admin "verified"/"deposit" + the user message
    st = c.get("/api/v1/status/TRADER123", headers=HEADERS).json()
    assert st["status"] == "verified" and st["telegram_user_id"] == 111
    # same state again: the user is answered (they asked), admins are NOT re-notified (dedupe)
    c.post("/api/v1/verify", json=body(), headers=HEADERS)
    assert len(c.tg_calls) == sent_first + 1


def test_below_minimum_and_unlinked_and_not_found(vclient):
    c = vclient(TraderLookup(True, True, [dep("d1", "10")]))
    assert c.post("/api/v1/verify", json=body(), headers=HEADERS).json()["status"] == "below_minimum"
    c = vclient(TraderLookup(True, False))
    j = c.post("/api/v1/verify", json=body(), headers=HEADERS).json()
    assert j["status"] == "unlinked" and j["linked"] is False
    assert c.get("/api/v1/status/TRADER123", headers=HEADERS).status_code == 404  # unlinked is never stored
    c = vclient(TraderLookup(False, False))
    assert c.post("/api/v1/verify", json=body(), headers=HEADERS).json()["status"] == "not_found"


def test_trader_id_bound_to_one_telegram_user(vclient):
    c = vclient(TraderLookup(True, True, [dep("d1", "60")]))
    assert c.post("/api/v1/verify", json=body(), headers=HEADERS).status_code == 200
    r = c.post("/api/v1/verify", json=body(telegram_user_id=222), headers=HEADERS)
    assert r.json()["status"] == "already_claimed"


def test_provider_exception_maps_to_502(vclient):
    class Boom(FakeProvider):
        async def lookup_trader(self, trader_id):
            raise RuntimeError("secret-internal-detail")

    c = vclient()
    c.fastapi_app.state.provider = Boom(TraderLookup(True, True))
    r = c.post("/api/v1/verify", json=body(), headers=HEADERS)
    assert r.status_code == 502 and "secret-internal-detail" not in r.text


# ---------------------------------------------------------------- re-verify webhook trigger
def test_verify_webhook_auth_and_flow(vclient, make_client):
    c = vclient(TraderLookup(True, True, [dep("d1", "60")]))
    assert c.post("/webhooks/affiliate/verify", json={"trader_id": "TRADER123"}).status_code == 401
    assert c.post("/webhooks/affiliate/verify", json={"trader_id": "TRADER123"}, headers={"X-Webhook-Secret": "x" * 40}).status_code == 401
    assert c.post("/webhooks/affiliate/verify", json={"x": 1}, headers=WH_HEADERS).json()["status"] == "ignored"
    # unknown trader id is ignored (never auto-creates a record from a webhook)
    assert c.post("/webhooks/affiliate/verify", json={"trader_id": "TRADER123"}, headers=WH_HEADERS).json()["reason"] == "unknown trader id"
    c.post("/api/v1/verify", json=body(), headers=HEADERS)
    r = c.post("/webhooks/affiliate/verify", json={"trader_id": "TRADER123"}, headers=WH_HEADERS)
    assert r.status_code == 202 and r.json()["status"] == "verified"
    # disabled auth mode refuses to process
    d = vclient(TraderLookup(True, True), webhook_auth_mode="disabled")
    assert d.post("/webhooks/affiliate/verify", json={"trader_id": "TRADER123"}).status_code == 503


def test_event_webhook_path_is_unchanged_and_still_drops_trader_fields(client):
    r = client.post("/webhooks/affiliate", json={"event_id": "E9", "status": "registration", "trader_id": "T1", "sumdep": "5"}, headers=WH_HEADERS)
    assert r.status_code == 200 and "T1" not in r.text


# ---------------------------------------------------------------- admin JSON + dashboard
def _login(c):
    tok = CSRF_RE.search(c.get("/admin/login").text).group(1)
    return c.post("/admin/login", data={"username": "admin", "password": ADMIN_PASSWORD, "csrf_token": tok}, follow_redirects=False)


def test_admin_verification_views_need_session(vclient):
    c = vclient(TraderLookup(True, True, [dep("d1", "60")]))
    c.post("/api/v1/verify", json=body(telegram_username="bob"), headers=HEADERS)
    assert c.get("/admin/api/users").status_code == 401
    assert c.get("/admin/api/history").status_code == 401
    assert _login(c).status_code == 303
    users = c.get("/admin/api/users").json()
    assert users[0]["trader_id"] == "TRADER123" and users[0]["status"] == "verified"
    assert c.get("/admin/api/users?q=nomatch").json() == []
    assert c.get("/admin/api/history").json()[0]["source"] == "bot"
    page = c.get("/admin").text
    assert "TRADER123" in page and "Verification history" in page


def test_dashboard_shows_not_operational_banner(vclient):
    c = vclient()
    _login(c)
    assert "VERIFICATION NOT OPERATIONAL" in c.get("/admin").text
